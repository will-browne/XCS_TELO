from BooleanEnvironment import BooleanEnvironment
from RealEnvironment import RealEnvironment
class Environment:
    def __init__(self, problemID, attributeNumber, reward, envtype):
        print("Initial Environment")
        if envtype=='b':
            self.env=BooleanEnvironment(problemID,attributeNumber,reward)
        if envtype=='r':
            self.env=RealEnvironment(problemID,attributeNumber,reward)