
import copy
from XCS_Operators import XCS_Operators
from RealEnvironment import RealEnvironment
from RepresentationSybolistTernary import RepresentationSymbolistTernary

#implement the CRA
class CRA:
    def __init__(self,population,env,oper,rep):
        #environment
        self.env=env

        #system operator
        self.oper=oper

        #a population based on list format
        self.population=population

        #a representation format
        self.rep=rep

        #predict accuracy
        self.accuracy=0

        self.Compacted_Population=[]

        #the name of the algorithm
        self.Name="CRA"

        #implement the CRA
        self.__CRA_Implement()
        

    def __getMatchSet(self,population):
        match_set=[]
        #print "begin"
        for i in range(0,len(population)):
            #0: condition (encoding)
            if(self.rep.Match(population[i][0])):
                #add matching classifier to the matchset
                match_set.append(i)
        return match_set

    def __AccuracyTest(self,population):
        correct=0.0
        #the number of instances need to be reviewed
        while self.env.Next()!=True:
            M=self.__getMatchSet(population)
            P_action=self.__Prediction(M,population)
            if self.env.Class==P_action:
                correct+=1
        accu=correct/(self.env.instanceNumber+1)
        return accu


    def __Prediction(self,match_set,population):
        actions_value=[]
        for i in range(0,self.env.NumberClasses):
            actions_value.append(0)

        for id in match_set:
             actions_value[population[id][1]]+=self.oper.GetPredictValue(population[id])

        #deault maxi
        max_id=0
        max_value=actions_value[0]
        for i in range(1,self.env.NumberClasses):
            if actions_value[i]>max_value:
                max_value=actions_value[i]
                max_id=i
        if len(match_set)==0:
            max_id=None
        return max_id

    #add additional column
    def __Add_additional_column_list(self,population):
        for rule in population:
            rule.append(0)
       

     #review the training_set
    def __Review_all_train_instance(self,population):
        self.__Add_additional_column_list(population)
        #the number of instances need to be reviewed
        while self.env.Next()!=True:
            M=self.__getMatchSet(population)
            for id in M:
                #record the number of matched instance
                population[id][-1]+=1

    def __CRA_Implement(self):

        #find the numerosity id in a rule
        numerosity_ID=self.oper.GetNumerosityID()
        #rank rules according to numerosity descending
        self.population.sort(key=lambda x:x[numerosity_ID],reverse=True)
        original_accu=self.__AccuracyTest(self.population)
        new_accuracy=0
        
        subset=[]

        count=0


        #stage 1
        #Find a maximally correct rule-set
        while new_accuracy<original_accu and len(subset)<len(self.population):
            subset.append(self.population[count])
            new_accuracy=self.__AccuracyTest(subset)
            count+=1

       
        #current accuracy
        original_accu=self.__AccuracyTest(subset)
        print("original accuracy",original_accu)
        #stage 2 remove rules which is potential redundant
        for i in range(0,len(subset)):
            hold_rule=subset[-1]
            subset.pop()
            new_accuracy=self.__AccuracyTest(subset)
            #reinsert the rule if the accuracy decrease
            if new_accuracy<original_accu:
                subset.insert(0,hold_rule)


        #stage 3 again remove replaceable rules
        self.__Review_all_train_instance(subset)
        #ranked by the number of matched instance
        subset.sort(key=lambda x:x[-1],reverse=True)

        final_set=[]

        
        Date_Set=copy.deepcopy(self.env.Get_states())
        
        while len(Date_Set)>0 and len(subset)>0:
            final_set.append(subset[0])
            del_list=[]
            #find the instances have been matched
            for id in range(0,len(Date_Set)):
                if self.rep.MatchState(subset[0][0],Date_Set[id]):
                    del_list.append(id)
            count=0
            for d_id in del_list:
                Date_Set.pop(d_id-count)
                count+=1
            subset.pop(0)

        
        self.accuracy=self.__AccuracyTest(final_set)

        self.Compacted_Population=final_set


        self.__print_population(self.Compacted_Population)
        print("final accuracy",self.accuracy)
        

    def __print_population(self,population):
        for rule in population:
            print(rule)