from XCS_Operators import XCS_Operators
from RepresentationSybolistTernary import RepresentationSymbolistTernary
from Config_StandardXCS import standard_XCS_config
from Environment import Environment
from CRA import CRA
from Fu1 import FU1
from Fu3 import FU3
from CRA2 import CRA2
from k1 import K1
from PDRC import PDRC
from QRC import QRC
from RCR import RCR
from RCR2 import RCR2
from RCR3 import RCR3
import os
import time
import copy
#address="Result/12_59_8_22MushroomFull.txt"
#ope=XCS_Operators()
#ope.Read_compact(address)

class Compact_Agent_R:
    # read a/multiple populations from a document
    def __init__(self,operator,env,representation,address,ImplementList):
        print("read agent")
        self.save_Address="RCompacted\\"
        self.oper=operator
        self.populations=[]
        self.__readPopulation(address)
        self.RunCompaction(ImplementList,env,operator,representation)


    #run the compaction algorithms
    def RunCompaction(self,ImplementList,env,operator,representation):
        #implement list [0:CRA, 1:CRA2, 2:FU1, 3:FU3
        # 4:K1, 5:PDRC 6:QRC 7:RCR 8:RCR2 9:RCR3]
        for id in ImplementList:
            if id==0:
                population=copy.deepcopy(self.populations[0])
                algorithm=CRA(population,env,operator,representation)
                self.__SaveResult(env,algorithm)
            elif id==1:
                population=copy.deepcopy(self.populations[0])
                algorithm=CRA2(population,env,operator,representation)
                self.__SaveResult(env,algorithm)
            elif id==2:
                population=copy.deepcopy(self.populations[0])
                algorithm=FU1(population,env,operator,representation)
                self.__SaveResult(env,algorithm)
            elif id==3:
                population=copy.deepcopy(self.populations[0])
                algorithm=FU3(population,env,operator,representation)
                self.__SaveResult(env,algorithm)
            elif id==4:
                population=copy.deepcopy(self.populations[0])
                algorithm=K1(population,env,operator,representation)
                self.__SaveResult(env,algorithm)
            elif id==5:
                population=copy.deepcopy(self.populations[0])
                algorithm=PDRC(population,env,operator,representation)
                self.__SaveResult(env,algorithm)
            elif id==6:
                population=copy.deepcopy(self.populations[0])
                algorithm=QRC(population,env,operator,representation)
                self.__SaveResult(env,algorithm)
            elif id==7:
                population=copy.deepcopy(self.populations)
                algorithm=RCR(population,env,operator,representation)
                self.__SaveResult(env,algorithm)
            elif id==8:
                population=copy.deepcopy(self.populations)
                algorithm=RCR2(population,env,operator,representation)
                self.__SaveResult(env,algorithm)
            elif id==9:
                population=copy.deepcopy(self.populations)
                algorithm=RCR3(population,env,operator,representation)
                self.__SaveResult(env,algorithm)



    # judge whether this file exist
    def __Is_File_Exist(self,file_Name):
        return os.path.exists(file_Name)

    # read a file list
    def __GetFileList(self,path,type):
        FileList=[]
        FindPath=path
        if self.__Is_File_Exist(FindPath):
            FileNames=os.listdir(FindPath)
            for i in FileNames:
                if type in i:
                    FileList.append(path+'\\'+i)
        return FileList

    # read a population
    def __readPopulation(self,address):
        read_list=self.__GetFileList(address,".txt")
        for add in read_list:
            print(add)
            population=self.oper.Read_compact(add)
            self.populations.append(population)

    #calculate a time
    def __startTimer(self):
        local_time= time.localtime(time.time())
        format_time=time.strftime('DAY: %Y-%m-%d  Time: %H : %M : %S',local_time)
        #print format_time
        #print local_time
        Hour= local_time[3]
        Min= local_time[4]
        second= local_time[5]
        return str(Hour)+"_"+str(Min)+"_"+str(second)+"_"


    #generate the name for saving
    def __GenerateName(self,environment,CompactOpaerator):
        TimeUse=self.__startTimer()
        Name=self.save_Address
        Name+=TimeUse+str(environment.AttributeNumber)+ environment.problemName[environment.ProblemId]+CompactOpaerator.Name+".txt"
        return Name


    #Convert a population to string
    def __ConvertToString(self,CompactOpaerator):
        result=""
        Population=CompactOpaerator.Compacted_Population
        for p in range(0,len(Population)):
                    temp=""
                    encod=""
                    for i in Population[p][0]:
                            encod+= str(i)+" "
                    temp+=encod+" : "+str(Population[p][1])+" "+str(Population[p][6])+"\n"
                    result+=temp
        return result

     #save the performance
    def __save_performance(self,txt,name):
        f=open(name,'wb')
        f.write(txt.encode())
        f.close()

    def __SaveResult(self,environment,CompactOpaerator):
        print("Begin Save")
        name=self.__GenerateName(environment,CompactOpaerator)
        result=self.__ConvertToString(CompactOpaerator)
        accuracy=str(CompactOpaerator.accuracy)+"\n"
        result+=accuracy
        self.__save_performance(result,name)




#address="Compact\\German"
#address="Compact\\Murshroom"

#address="Compact\\ZOO"
address="Compact\\6MUX"
ImplementList=[1,2,3,4,5,6,7,8,9]
ope=XCS_Operators()
config=standard_XCS_config()
env=Environment(0,6,1000,'b')
rep=RepresentationSymbolistTernary(env.env,config)
CA=Compact_Agent_R(ope,env.env,rep,address,ImplementList)