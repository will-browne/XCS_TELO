from Compacted_Operators import Compacted_Operator
from Compacted_Operators import Compacted_Operator_OldXCS
from Compacted_Operators import Compacted_Operator_UCS
from Compacted_Operators import Compacted_Operator_ASCS
from Compacted_Operators import Compacted_Model
import copy
#from mpl_toolkits.mplot3d import axes3d
import matplotlib.pyplot as plt
import os
import matplotlib.lines as mlines
import matplotlib as mpl
import numpy as np
from Environment import Environment

class AFIM:
    def __init__(self,address,operator):
        self.Oper=operator
        self.population=self.Oper.Read(address)
        self.ActionList=[]
        self.AFIM_Data=self.__ActionBaedFeatureImportanceMap()
        

    def __Conver_to_Cluster(self):
        #0: the condition 
        length=len(self.population[0][0])
        cluster=[]
        actionList=[]
        for i in range(0,length+1):
            temp=[]
            cluster.append(temp)

        for rule in self.population:
            level=self.Oper.count_dontcare(rule)
            cluster[level].append(rule)
            #1 action 
            if not rule[1] in actionList:
                actionList.append(rule[1])

        return cluster, actionList

    def __ActionBaedFeatureImportanceMap(self):
        
        #Initial the action based distribution list
        distribution_list=[]
        length=len(self.population[0][0])
        
        clustered,action_list=self.__Conver_to_Cluster()

        self.ActionList=action_list
        for i in range(0,len(clustered)):
            temp=[]
            for j in range(0,length):               
                temp.append(0)
            distribution_list.append(temp)

        #Action distributed list
        G_distribution_list=[]
        for i in range(0,len(action_list)):
            temp=copy.deepcopy(distribution_list)
            G_distribution_list.append(temp)

        G_count_list=copy.deepcopy(G_distribution_list)


        #print distribution_list
        for i in range(0,len(clustered)):
            if len(clustered[i])!=0:
                for rule in clustered[i]:
                    for cond_l in range(0,length):
                        if rule[0][cond_l]!='#':
                            G_distribution_list[rule[1]][i][cond_l]+=1
                            G_count_list[rule[1]][i][cond_l]+=1
                        else:
                            G_count_list[rule[1]][i][cond_l]+=1


                for d_l in range(0,length):
                    for action in action_list:
                        if G_count_list[action][i][d_l]!=0:
                            G_distribution_list[action][i][d_l]=1.0*G_distribution_list[action][i][d_l]/G_count_list[action][i][d_l]

        print (G_distribution_list)

        return G_distribution_list


class FIM:
    def __init__(self,address,operator):
        self.Oper=operator
        self.population=self.Oper.Read(address)
        self.FIM_Data=self.__FeatureImportanceMap()
        

    def __Conver_to_Cluster(self):
        #0: the condition 
        length=len(self.population[0][0])
        cluster=[]
        actionList=[]
        for i in range(0,length+1):
            temp=[]
            cluster.append(temp)

        for rule in self.population:
            level=self.Oper.count_dontcare(rule)
            cluster[level].append(rule)


        return cluster

    def __FeatureImportanceMap(self):
        
        #Initial the action based distribution list
        distribution_list=[]
        length=len(self.population[0][0])
        
        clustered=self.__Conver_to_Cluster()

        for i in range(0,len(clustered)):
            temp=[]
            for j in range(0,length):               
                temp.append(0)
            distribution_list.append(temp)


        count_list=copy.deepcopy(distribution_list)


        #print distribution_list
        for i in range(0,len(clustered)):
            if len(clustered[i])!=0:
                for rule in clustered[i]:
                    for cond_l in range(0,length):
                        if rule[0][cond_l]!='#':
                            distribution_list[i][cond_l]+=1
                            count_list[i][cond_l]+=1
                        else:
                            count_list[i][cond_l]+=1


                for d_l in range(0,length):
                        if count_list[i][d_l]!=0:
                            distribution_list[i][d_l]=1.0*distribution_list[i][d_l]/count_list[i][d_l]

        print (distribution_list)

        return distribution_list


class AFVM:
    def __init__(self,address,operator):
        self.Oper=operator
        self.population=self.Oper.Read(address)
        self.ActionList=[]
        self.AFVM_Data=self.__ActionBaedFeatureAverageValueMap()

        

    def __Conver_to_Cluster(self):
        #0: the condition 
        length=len(self.population[0][0])
        cluster=[]
        actionList=[]
        for i in range(0,length+1):
            temp=[]
            cluster.append(temp)

        for rule in self.population:
            level=self.Oper.count_dontcare(rule)
            cluster[level].append(rule)
            #1 action 
            if not rule[1] in actionList:
                actionList.append(rule[1])

        return cluster, actionList

   

    def __ActionBaedFeatureAverageValueMap(self):
        
        #Initial the action based distribution list
        distribution_list=[]
        length=len(self.population[0][0])
        clustered,action_list=self.__Conver_to_Cluster()
        self.ActionList=action_list
        for i in range(0,len(clustered)):
            temp=[]
            for j in range(0,length):               
                temp.append(0)
            distribution_list.append(temp)

        #Action distributed list
        G_distribution_list=[]
        for i in range(0,len(action_list)):
            temp=copy.deepcopy(distribution_list)
            G_distribution_list.append(temp)

        G_count_list=copy.deepcopy(G_distribution_list)

        #print distribution_list
        for i in range(0,len(clustered)):
            if len(clustered[i])!=0:
                for rule in clustered[i]:
                    for cond_l in range(0,length):
                        if rule[0][cond_l]!='#':
                            if rule[1]==1:
                                G_distribution_list[rule[1]][i][cond_l]+=int(rule[0][cond_l])
                                G_count_list[rule[1]][i][cond_l]+=1

                            if rule[1]==0:
                                G_distribution_list[rule[1]][i][cond_l]+=int(rule[0][cond_l])-1
                                G_count_list[rule[1]][i][cond_l]+=1


                for d_l in range(0,length):
                    for action in action_list:
                        if G_count_list[action][i][d_l]!=0:
                            G_distribution_list[action][i][d_l]=1.0*G_distribution_list[action][i][d_l]/G_count_list[action][i][d_l]

        print (G_distribution_list)
        #print len(distribution_list)
        return G_distribution_list

class AFIM_Real:
    def __init__(self,address,operator):
        self.Oper=operator
        self.population=self.Oper.Read(address)
        self.ActionList=[]
        self.AFIM_Data_Positive=self.__ActionBaedFeatureImportanceMap(1000)
        self.AFIM_Data_Negative=self.__ActionBaedFeatureImportanceMap(0)

    def __Conver_to_Cluster(self,prediction):
        #0: the condition 
        length=len(self.population[0][0])
        cluster=[]
        actionList=[]
        for i in range(0,length+1):
            temp=[]
            cluster.append(temp)

        for rule in self.population:
            if rule[2]==prediction:
                level=self.Oper.count_dontcare(rule)
                cluster[level].append(rule)
                #1 action 
                if not rule[1] in actionList:
                    actionList.append(rule[1])

        return cluster, actionList

    def __ActionBaedFeatureImportanceMap(self,prediction):
        
        #Initial the action based distribution list
        distribution_list=[]
        length=len(self.population[0][0])
        
        clustered,action_list=self.__Conver_to_Cluster(prediction)

        self.ActionList=action_list
        for i in range(0,len(clustered)):
            temp=[]
            for j in range(0,length):               
                temp.append(0)
            distribution_list.append(temp)

        #Action distributed list
        G_distribution_list=[]
        for i in range(0,len(action_list)):
            temp=copy.deepcopy(distribution_list)
            G_distribution_list.append(temp)

        G_count_list=copy.deepcopy(G_distribution_list)


        #print distribution_list
        for i in range(0,len(clustered)):
            if len(clustered[i])!=0:
                for rule in clustered[i]:
                    for cond_l in range(0,length):
                        if rule[0][cond_l]!='#':
                            G_distribution_list[rule[1]][i][cond_l]+=1
                            G_count_list[rule[1]][i][cond_l]+=1
                        else:
                            G_count_list[rule[1]][i][cond_l]+=1


                for d_l in range(0,length):
                    for action in action_list:
                        if G_count_list[action][i][d_l]!=0:
                            G_distribution_list[action][i][d_l]=1.0*G_distribution_list[action][i][d_l]/G_count_list[action][i][d_l]
                            if prediction==0:
                                G_distribution_list[action][i][d_l]=0-G_distribution_list[action][i][d_l]

        print (G_distribution_list)

        return G_distribution_list

class AFVM_Real:
    def __init__(self,address,operator):
        self.Oper=operator
        self.population=self.Oper.Read(address)
        self.ActionList=[]
        self.AFVM_Data_Positive=self.__ActionBaedFeatureAverageValueMap(1000)
        self.AFVM_Data_Negative=self.__ActionBaedFeatureAverageValueMap(0)

    def __Conver_to_Cluster(self,prediction):
        #0: the condition 
        length=len(self.population[0][0])
        cluster=[]
        actionList=[]
        for i in range(0,length+1):
            temp=[]
            cluster.append(temp)

        for rule in self.population:
            if rule[2]==prediction:
                level=self.Oper.count_dontcare(rule)
                cluster[level].append(rule)
                #1 action 
                if not rule[1] in actionList:
                    actionList.append(rule[1])

        return cluster, actionList

    def __ActionBaedFeatureAverageValueMap(self, prediction):
        
        #Initial the action based distribution list
        distribution_list=[]
        #for store the specified values
        specify_values=[]
        length=len(self.population[0][0])
        
        clustered,action_list=self.__Conver_to_Cluster(prediction)
        print(action_list)


        self.ActionList=action_list
        for i in range(0,len(clustered)):
            temp=[]
            for j in range(0,length):               
                temp.append(0)
            distribution_list.append(temp)

        for i in range(0,len(clustered)):
            temp=[]
            for j in range(0,length):
                values=[]
                temp.append(values)
            specify_values.append(temp)

        #Action distributed list
        G_distribution_list=[]
        for i in range(0,len(action_list)):
            temp=copy.deepcopy(distribution_list)
            G_distribution_list.append(temp)

        G_count_list=[]
        for i in range(0,len(action_list)):
            temp=copy.deepcopy(specify_values)
            G_count_list.append(temp)

        #print distribution_list
        for i in range(0,len(clustered)):
            if len(clustered[i])!=0:
                for rule in clustered[i]:
                    for cond_l in range(0,length):
                        if rule[0][cond_l]!='#':
                                G_distribution_list[rule[1]][i][cond_l]+=1
                                if not rule[0][cond_l] in  G_count_list[rule[1]][i][cond_l]:
                                    G_count_list[rule[1]][i][cond_l].append(rule[0][cond_l])

                for d_l in range(0,length):
                    for action in action_list:
                        if G_count_list[action][i][d_l]!=0:
                            if prediction==0:
                                G_distribution_list[action][i][d_l]=0-G_distribution_list[action][i][d_l]



                

        #print (G_distribution_list)
        #print(G_count_list)
        #print len(distribution_list)
        return G_distribution_list, G_count_list
class Visualization:
    def __init__(self,path):
        #the datas for generating the visualization result
        #self.data=data
        #the path for saving the visualization results
        self.png_path=path
        #the list of actions for this domain
        #self.action_list=actionList
    #can be used for heat map
    def __Rainbown_color(self,length):
        R=0xff
        G_begin=0xff
        B_begin=0xff
        Rstep=(0xff-0xfc)//length
        Gstep=(0xff-0x82)//length
        Bstep=(0xff-0x4a)//length
        color='#'
        colors=[]
        for i in range(0,length):
            #color=color+str(hex(R))+str(hex(B_begin+step*i))+str(hex(G_begin-step*i))
            color=color+self.__translate_sixteen_string(R-Rstep*i)+self.__translate_sixteen_string(G_begin-Gstep*i)+self.__translate_sixteen_string(B_begin-Bstep*i)
            colors.append(color)
            color='#'
        #for co in colors:
        #    print co
        return colors

    def __Rainbown_Green(self,length):
        R=0xff
        G_begin=0xff
        B_begin=0xff
        Rstep=(0xff-0x2a)//length
        Gstep=(0xff-0x7e)//length
        Bstep=(0xff-0x19)//length
        color='#'
        colors=[]
        for i in range(0,length):
            #color=color+str(hex(R))+str(hex(B_begin+step*i))+str(hex(G_begin-step*i))
            color=color+self.__translate_sixteen_string(R-Rstep*i)+self.__translate_sixteen_string(G_begin-Gstep*i)+self.__translate_sixteen_string(B_begin-Bstep*i)
            colors.append(color)
            color='#'
        #for co in colors:
        #    print co
        return colors

    def __Rainbown_Reversed(self,length):
        R=0xfc
        G_begin=0x82
        B_begin=0x4a
        Rstep=(0xff-0xfc)//length
        Gstep=(0xff-0x82)//length
        Bstep=(0xff-0x4a)//length
        color='#'
        colors=[]
        for i in range(0,length-1):
            #color=color+str(hex(R))+str(hex(B_begin+step*i))+str(hex(G_begin-step*i))
            color=color+self.__translate_sixteen_string(R+Rstep*i)+self.__translate_sixteen_string(G_begin+Gstep*i)+self.__translate_sixteen_string(B_begin+Bstep*i)
            colors.append(color)
            color='#'
        #for co in colors:
        #    print co
        colors.append('#ffffff')
        return colors

    def __translate_sixteen_string(self,value):
        if abs(value)<0x10:
            #print value, '           ', 0x10
            result='0'
            result=result+str(hex(value)).split('x')[-1]
        else:
         result=str(hex(value)).split('x')[-1]
        return result   

    def __Detect_Inforative_levels(self,list):
         result=[]
         for i in range(0,len(list)):
             for j in list[i]:
                 if j!=0:
                    result.append(i)
                    break
         return result

    def Drew_MultiAction3D_Boolean(self,title,data,actionList,step):
        fig=plt.figure(figsize=(10, 10), dpi=150)
        ax1=fig.add_subplot(111,projection='3d')
        z_first=np.asarray(data[0])
        z=z_first.T


        
        xlabels_t=[]       
        for i in range(0,len(z)):
            xlabels_t.append(str(i))
        xlabels=np.array(xlabels_t)
        xpos=np.arange(xlabels.shape[0])

        ylabels_t=[]       
        for i in range(0,len(z[0])):
            ylabels_t.append(str(i))
        ylabels=np.array(ylabels_t)
        ypos=np.arange(ylabels.shape[0])



        xposM, yposM=np.meshgrid(xpos,ypos,copy=False)

        dx=0.3
        dy=0.1

        ax1.w_xaxis.set_ticks(xpos + dx/2.)
        ax1.w_xaxis.set_ticklabels(xlabels)

        ax1.w_yaxis.set_ticks(ypos + dy/3.)
        ax1.w_yaxis.set_ticklabels(ylabels)

        color_list=[ 'tab:orange', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan','tab:blue', 'tab:orange', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan']

        line_list=['--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':']
        #for act in range(6,7):
        for act in range(0,len(actionList)):
            important_list=self.__Detect_Inforative_levels(data[act])
            z_first=np.asarray(data[act])
            z=z_first.T

            y=[]

            for i in range(0,len(z[0])):
                y.append(i)



            for i in range(0,len(z)):
                x=[i]*len(z[i])
                if len(z)>=20:


                    ax1.plot(x, y, z[i], line_list[act],color=color_list[act],lw=3,alpha=3)

                    ax1.legend()
                    for j in range(0,len(z[i])):
                        if z[i][j] !=0 and i%4==0:

                            ax1.text(i, j, z[i][j]+0.1, str(round(z[i][j],2)), color=color_list[act])  
                else:
                    ax1.plot(x, y, z[i], line_list[act], color=color_list[act],lw=2)
                    ax1.legend()
                    for j in range(0,len(z[i])):
                        if z[i][j]!=0:
                            ax1.text(i, j, z[i][j]+0.01, str(round(z[i][j],2)), color=color_list[act])               

        ax1.set_xlabel('X ', fontsize=20)
        ax1.set_title(title, fontsize=30)
        ax1.set_ylabel('Y', fontsize=20)
        ax1.set_zlabel("Z", fontsize=20)

        for angle in range(1, 360,step):
            ax1.view_init(30, angle)
            plt.draw()
            png_complete_name = self.png_path +"\\"+ str(angle) + ".png"
            # fig.savefig(png_complete_name, dpi=(400))
            fig.savefig(png_complete_name,bbox_inches='tight')
            #fig.savefig(png_complete_name)
            plt.pause(.001)
        plt.show()

    def Drew_Simple3D_Boolean(self,title,data,step):
        fig=plt.figure(figsize=(10, 10), dpi=150)
        ax1=fig.add_subplot(111,projection='3d')
        z_first=np.asarray(data)
        z=z_first.T


        
        xlabels_t=[]       
        for i in range(0,len(z)):
            xlabels_t.append(str(i))
        xlabels=np.array(xlabels_t)
        xpos=np.arange(xlabels.shape[0])

        ylabels_t=[]       
        for i in range(0,len(z[0])):
            ylabels_t.append(str(i))
        ylabels=np.array(ylabels_t)
        ypos=np.arange(ylabels.shape[0])



        xposM, yposM=np.meshgrid(xpos,ypos,copy=False)

        dx=0.3
        dy=0.1

        ax1.w_xaxis.set_ticks(xpos + dx/2.)
        ax1.w_xaxis.set_ticklabels(xlabels)

        ax1.w_yaxis.set_ticks(ypos + dy/3.)
        ax1.w_yaxis.set_ticklabels(ylabels)

        color_list=['tab:orange', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan','tab:blue', 'tab:orange', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan']

        line_list=['--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':']

        important_list=self.__Detect_Inforative_levels(data)
        z_first=np.asarray(data)
        z=z_first.T

        y=[]

        for i in range(0,len(z[0])):
            y.append(i)



        for i in range(0,len(z)):
            x=[i]*len(z[i])
            if len(z)>=20:
                ax1.plot(x, y, z[i], line_list[0],color=color_list[0],lw=3,alpha=3)

                ax1.legend()
                for j in range(0,len(z[i])):
                    if z[i][j] !=0 and i%4==0:
                        ax1.text(i, j, z[i][j]+0.1, str(round(z[i][j],2)), color=color_list[0])  
            else:
                ax1.plot(x, y, z[i], line_list[0], color=color_list[0],lw=2)
                ax1.legend()
                for j in range(0,len(z[i])):
                    if z[i][j]!=0:
                        ax1.text(i, j, z[i][j]+0.01, str(round(z[i][j],2)), color=color_list[0])               

        ax1.set_xlabel('X ', fontsize=20)
        ax1.set_title(title, fontsize=30)
        ax1.set_ylabel('Y', fontsize=20)
        ax1.set_zlabel("Z", fontsize=20)

        for angle in range(1, 360,step):
            ax1.view_init(30, angle)
            plt.draw()
            png_complete_name = self.png_path +"\\"+ str(angle) + ".png"
            # fig.savefig(png_complete_name, dpi=(400))
            fig.savefig(png_complete_name,bbox_inches='tight')
            #fig.savefig(png_complete_name)
            plt.pause(.001)
        plt.show()

    def __DetectMaxMin(self,data):
        max=-10000
        min=100000
        for i in range(0,len(data)):
             for j in data[i]:
                 if j>max:
                    max=j
                 if j<min:
                     min=j
        return max,min

    def DrewHeatMapSimple2D(self,title,data):
        colors=self.__Rainbown_color(22)
        max,min=self.__DetectMaxMin(data)
        color_step=1.0*(max-min)/20
        #number of clusters
        length=len(data)
        ax = plt.gca()
        my_x_ticks = np.arange(0, length-1, 1)
        my_y_ticks = np.arange(0, length, 1)
        plt.xlim((0, length-1))
        plt.ylim((0, length))
        plt.xticks(my_x_ticks)
        plt.yticks(my_y_ticks)
        for i in range(0,len(data)):
             for j in range(0,len(data[i])):
                 #i cluster id j attribute id
                 if data[i][j]==min:
                     colorId=0
                 elif data[i][j]==max:
                     colorId=-1
                 else:
                     addStep=int((data[i][j]-min)/color_step)
                     colorId=1+addStep
                 rect=plt.Rectangle((j,i),1,1, color=colors[colorId])
                 ax.add_patch(rect)


        ax.set_xlabel('x',fontsize=18)
        ax.set_ylabel('y',fontsize=18)
        plt.title(title,fontsize=18)
        png_complete_name = self.png_path +"\\"+ str("FIM") 
        plt.savefig(png_complete_name,bbox_inches='tight')
        plt.show()

    def DrewHeatMapAFIM(self,title,Inputdata):
        colors=[]
        colors_p=self.__Rainbown_color(22)
        colors_n=self.__Rainbown_Green(22)
        colors.append(colors_p)
        colors.append(colors_n)
        

        count=0
        for data in Inputdata:
            max,min=self.__DetectMaxMin(data)
            color_step=1.0*(max-min)/20
            #number of clusters
            length=len(data)
            ax = plt.gca()
            my_x_ticks = np.arange(0, length-1, 1)
            my_y_ticks = np.arange(0, length, 1)
            plt.xlim((0, length-1))
            plt.ylim((0, length))
            plt.xticks(my_x_ticks)
            plt.yticks(my_y_ticks)
            for i in range(0,len(data)):
                for j in range(0,len(data[i])):
                    #i cluster id j attribute id
                    if data[i][j]==min:
                        colorId=0
                    elif data[i][j]==max:
                        colorId=-1
                    else:
                        addStep=int((data[i][j]-min)/color_step)
                        colorId=1+addStep
                    rect=plt.Rectangle((j,i),1,1, color=colors[count][colorId])
                    ax.add_patch(rect)


            ax.set_xlabel('x',fontsize=18)
            ax.set_ylabel('y',fontsize=18)
            name=title+" Action: "+str(count)
            plt.title(name,fontsize=18)
            png_complete_name = self.png_path +"\\"+ "AFIM"+str(count)
            plt.savefig(png_complete_name,bbox_inches='tight')
            plt.show()
            count+=1

    def DrewHeatMapAFVM(self,title,Inputdata):
        colors=[]
        colors_p=self.__Rainbown_Green(22)
        colors_n=self.__Rainbown_Reversed(22)
        colors.append(colors_n)
        colors.append(colors_p)
        

        count=0
        for data in Inputdata:
            max,min=self.__DetectMaxMin(data)
            color_step=1.0*(max-min)/20
            #number of clusters
            length=len(data)
            ax = plt.gca()
            my_x_ticks = np.arange(0, length-1, 1)
            my_y_ticks = np.arange(0, length, 1)
            plt.xlim((0, length-1))
            plt.ylim((0, length))
            plt.xticks(my_x_ticks)
            plt.yticks(my_y_ticks)
            for i in range(0,len(data)):
                for j in range(0,len(data[i])):
                    #i cluster id j attribute id
                    if data[i][j]==min:
                        colorId=0
                    elif data[i][j]==max:
                        colorId=-1
                    else:
                        addStep=int((data[i][j]-min)/color_step)
                        colorId=1+addStep
                    rect=plt.Rectangle((j,i),1,1, color=colors[count][colorId])
                    ax.add_patch(rect)


            ax.set_xlabel('x',fontsize=18)
            ax.set_ylabel('y',fontsize=18)
            name=title+" Action: "+str(count)
            plt.title(name,fontsize=18)
            png_complete_name = self.png_path +"\\"+ "AFVM"+str(count)
            plt.savefig(png_complete_name,bbox_inches='tight')
            plt.show()
            count+=1

    def DrewLabels(self):

        colors_n=self.__Rainbown_color(22)
        colors_nr=self.__Rainbown_Reversed(22)
        colors_p=self.__Rainbown_Green(22)

        ax = plt.gca()
        plt.text(1,17.5,"FIM: attribute specification ratio",fontsize=15)
        plt.text(1,16.2,"0%",fontsize=15)
        for i in range(0, len(colors_p)):
            y_value=16
            rect=plt.Rectangle((i+2,y_value),1,1, color=colors_n[i])
            ax.add_patch(rect)
        plt.text(i+3,16.2,"100%",fontsize=15)

        plt.text(1,14.5,"AFIM: attribute specification ratio, action 1",fontsize=15)
        plt.text(1,13.2,"0%",fontsize=15)
        for i in range(0, len(colors_p)):
            y_value=13
            rect=plt.Rectangle((i+2,y_value),1,1, color=colors_p[i])
            ax.add_patch(rect)
        plt.text(i+3,13.2,"100%",fontsize=15)

        plt.text(1,11.5,"AFIM: attribute specification ratio, action 0",fontsize=15)
        plt.text(1,10.2,"0%",fontsize=15)
        for i in range(0, len(colors_p)):
            y_value=10
            rect=plt.Rectangle((i+2,y_value),1,1, color=colors_n[i])
            ax.add_patch(rect)
        plt.text(i+3,10.2,"100%",fontsize=15)


        plt.text(1,8.5,"AFIM: specified attribute average value, action 1",fontsize=15)
        plt.text(1,7.2,"0",fontsize=15)
        for i in range(0, len(colors_p)):
            y_value=7
            rect=plt.Rectangle((i+2,y_value),1,1, color=colors_p[i])
            ax.add_patch(rect)
        plt.text(i+3,7.2,"  1",fontsize=15)

        plt.text(1,5.5,"AFIM: specified attribute average value, action 0",fontsize=15)
        plt.text(1,4.2,"-1",fontsize=15)
        for i in range(0, len(colors_p)):
            y_value=4
            rect=plt.Rectangle((i+2,y_value),1,1, color=colors_nr[i])
            ax.add_patch(rect)
        plt.text(i+3,4.2," 0",fontsize=15)

        plt.xlim((0, 28))
        plt.ylim((0, 20))
        ax.axes.get_yaxis().set_visible(False)
        ax.axes.get_xaxis().set_visible(False)

        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.spines['bottom'].set_visible(False)
        ax.spines['left'].set_visible(False)
        
        png_complete_name = self.png_path +"\\"+ "label"
        plt.savefig(png_complete_name,bbox_inches='tight')
        plt.show()

    def Drew_MultiAction3D_Real(self,P_data,N_data,actionList,step,env):
        

        color_list=[ 'tab:orange', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan','tab:blue', 'tab:orange', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan']

        line_list=['--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':']
        #for act in range(6,7):
        for act in range(0,len(actionList)):
            fig=plt.figure(figsize=(10, 10), dpi=150)
            ax1=fig.add_subplot(111,projection='3d')
            z_first=np.asarray(P_data[0])
            z=z_first.T


        
            xlabels_t=[]       
            for i in range(0,len(z)):
                xlabels_t.append(str(i))
            xlabels=np.array(xlabels_t)
            xpos=np.arange(xlabels.shape[0])

            ylabels_t=[]       
            for i in range(0,len(z[0])):
                ylabels_t.append(str(i))
            ylabels=np.array(ylabels_t)
            ypos=np.arange(ylabels.shape[0])
            ax1.axes.set_zlim3d(bottom=-1, top=1) 


            xposM, yposM=np.meshgrid(xpos,ypos,copy=False)

            dx=0.3
            dy=0.1

            ax1.w_xaxis.set_ticks(xpos + dx/2.)
            ax1.w_xaxis.set_ticklabels(xlabels)

            ax1.w_yaxis.set_ticks(ypos + dy/3.)
            ax1.w_yaxis.set_ticklabels(ylabels)



            z_first=np.asarray(P_data[act])
            z=z_first.T

            z_second=np.asarray(N_data[act])
            z2=z_second.T

            y=[]

            for i in range(0,len(z[0])):
                y.append(i)



            for i in range(0,len(z)):
                x=[i]*len(z[i])
                ax1.plot(x, y, z[i], line_list[0], color=color_list[0],lw=2)
                ax1.plot(x, y, z2[i], line_list[1], color=color_list[1],lw=2)
                ax1.legend()
                for j in range(0,len(z[i])):
                        if z[i][j]!=0:
                            ax1.text(i, j, z[i][j]+0.3, str(round(z[i][j],2)), color=color_list[0])
                        if z2[i][j]!=0:
                            ax1.text(i, j, z2[i][j]-0.3, str(abs( round(z2[i][j],2))), color=color_list[1])

                ax1.set_xlabel('X ', fontsize=20)
                ax1.set_title(env.PlausibleClassesName[act], fontsize=15)
                ax1.set_ylabel('Y', fontsize=20)
                ax1.set_zlabel("Z", fontsize=20)

            for angle in range(1, 360,step):
                ax1.view_init(30, angle)
                plt.draw()
                png_complete_name = self.png_path +"\\"+ env.PlausibleClassesName[act]+str(angle) + ".png"
                # fig.savefig(png_complete_name, dpi=(400))
                fig.savefig(png_complete_name,bbox_inches='tight')
                #fig.savefig(png_complete_name)
                plt.pause(.001)
            plt.show()

    def Drew_MultiValue_Real(self,P_data,N_data,actionList,step,env):
        

        color_list=[ 'tab:orange', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan','tab:blue', 'tab:orange', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan']

        line_list=['--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':']
        #for act in range(6,7):
        for act in range(0,len(actionList)):
            fig=plt.figure(figsize=(10, 10), dpi=150)
            ax1=fig.add_subplot(111,projection='3d')
            z_first=np.asarray(P_data[0][0])
            z=z_first.T

            print(P_data[0][0])
        
            xlabels_t=[]       
            for i in range(0,len(z)):
                xlabels_t.append(str(i))
            xlabels=np.array(xlabels_t)
            xpos=np.arange(xlabels.shape[0])

            ylabels_t=[]       
            for i in range(0,len(z[0])):
                ylabels_t.append(str(i))
            ylabels=np.array(ylabels_t)
            ypos=np.arange(ylabels.shape[0])
            #ax1.axes.set_zlim3d(bottom=-1, top=1) 

            ax1.axes.set_xlim3d(left=0, right=len(xpos)) 
            ax1.axes.set_ylim3d(bottom=0, top=len(ypos)) 
            xposM, yposM=np.meshgrid(xpos,ypos,copy=False)

            dx=0.3
            dy=0.1

            ax1.w_xaxis.set_ticks(xpos + dx/2.)
            ax1.w_xaxis.set_ticklabels(xlabels)

            ax1.w_yaxis.set_ticks(ypos + dy/3.)
            ax1.w_yaxis.set_ticklabels(ylabels)



            z_first=np.asarray(P_data[0][act])
            z=z_first.T

            z_second=np.asarray(N_data[0][act])
            z2=z_second.T

            y=[]

            for i in range(0,len(z[0])):
                y.append(i)



            

            nx=[]
            ny=[]
            dz=[]
            for i in range(0,len(z)):
                for j in range(0,len(z[i])):
                    if z[i][j]!=0:
                        dz.append(z[i][j])
                        nx.append(i)
                        ny.append(j)
            dx=np.ones(len(nx))
            dy=np.ones(len(ny))
            nz=np.zeros(len(dz))

            if len(nz)>0:               
                ax1.bar3d(nx, ny, nz, dx, dy, dz)
                    

            nx=[]
            ny=[]
            dz=[]
            for i in range(0,len(z)):
                for j in range(0,len(z2[i])):
                    if z2[i][j]!=0:
                        dz.append(z2[i][j])
                        nx.append(i)
                        ny.append(j)
            dx=np.ones(len(nx))
            dy=np.ones(len(ny))
            nz=np.zeros(len(dz))
                #print(dz)
            if len(nz)>0:            
                   ax1.bar3d(nx, ny, nz, dx, dy, dz)
       
            for j in range(0,len(z[i])):
                        if z[i][j]!=0:
                            ax1.text(i, j, z[i][j]+0.3, str(round(z[i][j],2)), color=color_list[0])
                #        if z2[i][j]!=0:
                #            ax1.text(i, j, z2[i][j]-0.3, str(abs( round(z2[i][j],2))), color=color_list[1])

            ax1.set_xlabel('X ', fontsize=20)
            ax1.set_title(env.PlausibleClassesName[act], fontsize=30)
            ax1.set_ylabel('Y', fontsize=20)
            ax1.set_zlabel("Z", fontsize=20)

            for angle in range(1, 360,step):
                ax1.view_init(30, angle)
                plt.draw()
                png_complete_name = self.png_path +"\\"+ str(angle) + ".png"
                # fig.savefig(png_complete_name, dpi=(400))
                fig.savefig(png_complete_name,bbox_inches='tight')
                #fig.savefig(png_complete_name)
                plt.pause(.001)
            plt.show()


#["Mushroom","MushroomFull","ZOO","German"]
#env=Environment(0,6,1000,'b')
#Address="RCompacted\\23_46_30_16ZOORCR3.txt"
#Address="RCompacted\\19_38_45_6MultiplexerRCR.txt"
#Address="RCompacted\\14_34_51_22MushroomFullRCR3.txt"
#Address="Compacted\\MUX6RCR2019_7_10_17_27_20.txt"
#Address="Compacted\\MUX37RCR2019_7_13_6_32_10.txt"
#Address="Compacted\\Carry12RCR32019_7_29_9_5_6.txt"
#Address="Compacted\\Carry10RCR32019_7_13_3_15_47.txt"
#Address="RCompacted\\14_34_51_22MushroomFullRCR3.txt"
#Address="RCompacted\\19_24_29_16ZOOPDRC.txt"
#operator=Compacted_Operator()
#operator=Compacted_Model()
#R_AFIM=AFIM(Address,operator)
#R_AFVM=AFVM(Address,operator)
#R_FIM=FIM(Address,operator)
#R_AFIM=AFIM_Real(Address,operator)
#R_AFVM=AFVM_Real(Address,operator)
#png_Path="V_Result"
#title="FIM: Heat Map 10-bits Carry"
#title="AFIM: Heat Map 10-bits Carry"
#title="AFVM: Heat Map 10-bits Carry"
#title="6-bits Multiplexer"
#V=Visualization(png_Path)
#V.Drew_Simple3D_Boolean(title,R_FIM.FIM_Data,360)
#V.DrewHeatMapSimple2D(title,R_FIM.FIM_Data)
#V.Drew_MultiAction3D_Real(R_AFIM.AFIM_Data_Positive,R_AFIM.AFIM_Data_Negative,R_AFIM.ActionList,10,env.env)
#V.Drew_MultiAction3D_Boolean(title,R_AFVM.AFVM_Data,R_AFVM.ActionList,360)
#V.DrewHeatMapAFVM(title,R_AFVM.AFVM_Data)
#V.Drew_MultiValue_Real(R_AFVM.AFVM_Data_Positive,R_AFVM.AFVM_Data_Negative,R_AFVM.ActionList,360,env.env)

#V.Drew_MultiAction3D_Boolean(title,R_AFIM.AFIM_Data,R_AFIM.ActionList,360)
#V.DrewHeatMapAFIM(title,R_AFIM.AFIM_Data)



#V.DrewLabels()


#Address="modelSample\\XCS_45598a9f_15e3_4393_b4e4_da00bc199dfdAgent_0c88186b_bf8d_48b4_9b68_061fb8233e79Problem_carryPlength_12FTime_DAY__2020_01_13__Time__02___42___03.txt"
#Address="modelSample\\XCS_45598a9f_15e3_4393_b4e4_da00bc199dfdAgent_1b9d0095_711d_4a4f_9a75_7baea46c2bc7Problem_majorityOnPlength_13FTime_DAY__2020_01_17__Time__02___16___08.txt"
#Address="modelSample\\XCS_45598a9f_15e3_4393_b4e4_da00bc199dfdAgent_2a8c9d7f_c67c_4764_ade2_7d21f6d4eb26Problem_multiplexerPlength_11FTime_DAY__2020_01_10__Time__01___09___23.txt"
#operator=Compacted_Operator_OldXCS()
#R_FIM=FIM(Address,operator)
#png_Path="V_Result"
#title="XCS 12-Bits Carry"
#title="XCS 13-Bits Majority-On"
#title="XCS 11-Bits Multiplexer"
#V=Visualization(png_Path)
#V.DrewHeatMapSimple2D(title,R_FIM.FIM_Data)

#Address="modelSample\\Carry_12_2020_1_13_5_28_5.txt"
#Address="modelSample\\Majority_13_2019_12_30_4_59_39.txt"
#Address="modelSample\\MUX_11_2020_1_9_20_19_50.txt"
#operator=Compacted_Operator_UCS()
#R_FIM=FIM(Address,operator)
#png_Path="V_Result"
#title="UCS 12-Bits Carry"
#title="UCS 13-Bits Majority-On"
#title="UCS 11-Bits Multiplexer"
#V=Visualization(png_Path)
#V.DrewHeatMapSimple2D(title,R_FIM.FIM_Data)

#Address="modelSample\\12_Carry_Population_2020_1_13_19_45_17.txt"
#Address="modelSample\\13_Majority_Population_2019_12_30_15_55_49.txt"
#Address="modelSample\\11_MUX_Population_2020_1_15_11_5_17.txt"
#operator=Compacted_Operator_ASCS()
#R_FIM=FIM(Address,operator)
#png_Path="V_Result"
#title="ASCS 12-Bits Carry"
#title="ASCS 13-Bits Majority-On"
#title="ASCS 11-Bits Multiplexer"
#V=Visualization(png_Path)
#V.DrewHeatMapSimple2D(title,R_FIM.FIM_Data)

title="6-bits Multiplexer"
env=Environment(0,6,1000,'b')
Address="RCompacted\\19_38_45_6MultiplexerRCR.txt"
operator=Compacted_Model()

#R_AFIM=AFIM(Address,operator)
R_AFVM=AFVM(Address,operator)
#R_FIM=FIM(Address,operator)
png_Path="V_Result"
V=Visualization(png_Path)
#print(R_AFVM.AFVM_Data)
#print(R_AFVM.ActionList)
#V.DrewHeatMapSimple2D(title,R_FIM.FIM_Data)
V.Drew_MultiAction3D_Boolean(title,R_AFVM.AFVM_Data,R_AFVM.ActionList,360)


#=AFIM(Address,operator)
#V.Drew_MultiAction3D_Boolean(title,R_AFIM.AFIM_Data,R_AFIM.ActionList,360)

#R_FIM=FIM(Address,operator)
#V.Drew_Simple3D_Boolean(title,R_FIM.FIM_Data,360)