from XCS_Operators import XCS_Operators
from RealEnvironment import RealEnvironment
from RepresentationSybolistTernary import RepresentationSymbolistTernary
import copy



class QRC:
    def __init__(self,population,env,oper,rep):
        #environment
        self.env=env

        #system operator
        self.oper=oper

        #the name of the algorithm
        self.Name="QRC"

        #a population based on list format
        self.population=population

        #a representation format
        self.rep=rep

        #predict accuracy
        self.accuracy=0

        self.Compacted_Population=[]

        self.__QRC_Implement()

    def __getMatchSet(self,population):
        match_set=[]
        #print "begin"
        for i in range(0,len(population)):
            #0: condition (encoding)
            if(self.rep.Match(population[i][0])):
                #add matching classifier to the matchset
                match_set.append(i)
        return match_set


    def __AccuracyTest(self,population):
        correct=0.0
        #the number of instances need to be reviewed
        while self.env.Next()!=True:
            M=self.__getMatchSet(population)
            P_action=self.__Prediction(M,population)
            if self.env.Class==P_action:
                correct+=1
        accu=correct/(self.env.instanceNumber+1)
        return accu


    def __Prediction(self,match_set,population):
        actions_value=[]
        for i in range(0,self.env.NumberClasses):
            actions_value.append(0)

        for id in match_set:
             actions_value[population[id][1]]+=self.oper.GetPredictValue(population[id])

        #deault maxi
        max_id=0
        max_value=actions_value[0]
        for i in range(1,self.env.NumberClasses):
            if actions_value[i]>max_value:
                max_value=actions_value[i]
                max_id=i
        if len(match_set)==0:
            max_id=None
        return max_id


    def __print_population(self,population):
        for rule in population:
            print(rule)



    def __QRC_Implement(self):
        #rank the population according to fitness
        fitnessId=self.oper.GetFitnessId()
        self.population.sort(key=lambda x:x[fitnessId],reverse=True)

        T_state=copy.deepcopy(self.env.Get_states())

        c_population=[]

        while len(T_state)>0 and len(self.population)>0:
            new_T_state=[]
            match_count=0
            rule=self.population[0]
            PID=self.oper.GetPredictionId()
            if rule[PID]>500:
                for state in T_state:
                    if self.rep.MatchState(rule[0],state):
                        match_count+=1
                    else:
                        new_T_state.append(state)

                if match_count>0:
                    c_population.append(rule)

            self.population.pop(0)

            T_state=copy.deepcopy(new_T_state)

        self.accuracy=self.__AccuracyTest(c_population)
        self.Compacted_Population=c_population

        self.__print_population(self.Compacted_Population)
        print("final accuracy",self.accuracy)