from XCS_Operators import XCS_Operators
from Environment import Environment
from RepresentationSybolistTernary import RepresentationSymbolistTernary
from Config_StandardXCS import standard_XCS_config
from XCS_Operators import XCS_Operators
from Environment import Environment

class XCS:
    def __init__(self):
        #for the problem
        self.ProblemId=3
        self.AttributeSize=6
        self.environment_type='r'# b for boolean domain r for rel domain
        self.reward=1000
        envstate=Environment(self.ProblemId,self.AttributeSize,self.reward,self.environment_type)
        self.env=envstate.env

        #load the setting for this XCS
        self.config=standard_XCS_config()

        #for the representation format
        self.representation=RepresentationSymbolistTernary(self.env,self.config)


        #get the training operators
        self.operators=XCS_Operators()


        #training iterations
        self.iterations=600000

        #how many iterations need to be tested
        self.testRate=50000

        #initial the population pool
        self.PopulationPool=self.operators.Initial_Population(self.env.AttributeNumber,self.env.NumberClasses)
        
        #maximum number of population pool
        self.MaxPop=6000



        #0: Population sum, 1: fitness sum, 2:delete weight sum 3:unmatched number
        self.Statistics=self.operators.Initial_Stastic()


        #prediction list
        self.PredictionList=[]
        self.UnmatchRate=[]
        self.Accuracy=[]

    def run(self):
        for i in range(1,self.iterations+1):
            self.env.RandomSample()
            M=self.operators.Matching(i,self.PopulationPool,self.representation,self.config,self.Statistics)

            #record the training performance
            self.PredictionList.append(self.operators.Prediction(self.PopulationPool,M,self.env,self.Statistics))

            selected_Action=self.operators.UpdateRandomActionSet(self.PopulationPool,self.env,M,self.config,self.Statistics)

            self.operators.RuleDiscovery(self.PopulationPool,M,selected_Action,i,self.Statistics,self.env,self.config,self.representation)

            self.operators.RemoveRules(self.PopulationPool,self.Statistics,self.MaxPop,self.config)

            

            if i%self.testRate==0:
                acc=1.0*sum(self.PredictionList)/len(self.PredictionList)
                unmatch=1.0*self.Statistics[3]/len(self.PredictionList)
                print("Accuracy: ",str(acc),"%" )
                print("Unmatched", str(unmatch),"%" )
                self.Accuracy.append(acc)
                self.UnmatchRate.append(unmatch)
                #empty the training performance list
                self.PredictionList=[]
                self.Statistics[3]=0

            

        #self.operators.PrintClassifiers(self.PopulationPool)
        print("Popsize:",self.Statistics[0])
        print("fitnessSum:",self.Statistics[1])
        print("deleteWeightSum",self.Statistics[2])
        self.operators.Save(self.PopulationPool,self.representation,self.env)

for mm in range(0,10):
    XCS_1=XCS()
    XCS_1.run()