#import random
from random import choice
import math
#import gc #(garbage collector)

class BooleanEnvironment:

    def __init__(self,problemId,AttributeNumber,maxReward=1000):
        #support problems [0: Multiplexer, 1:Carry, 2:MajorityOn]
        self.ProblemId=problemId

        #support problem name
        self.problemName=["Multiplexer","Carry","Majority-On"]

        # number of attributes
        self.AttributeNumber=AttributeNumber

        # this problem's attributes' plausible values
        self.AttributePLausibleValue=["0","1"]

        #the plausible actions of these problem
        self.PlausibleClassesId=[0,1]
        self.PlausibleClassesName=["0","1"]

        #number of classes for these problems
        self.NumberClasses=2

        #the plausible values for each attributes
        self.PlausibleAtributeValueList=[]
        self.Initial_Plausible_Attribute_Values()
        self.AttributeList=[]
        self.Initial_Attribute_List()

        #if this is a multiplexer problem, inilize the post bit for this problem
        # posbits and corresonding problems' length for the Multiplexer problem
        self.multiplexer_posbits=[1,2,3,4,5,6,7,8,9,10,11]
        self.multiplexer_lengths=[3,6,11,20,37,70,135,264,521,1034,2059]

        self.multiplexer_posbit=0;

        # find the corresponding post bits
        if self.ProblemId==0:
            self.Identify_posbits_Multiplexer()

        #reward for reinforcement learning
        self.Reward=maxReward

        #the current state
        self.State="";

        #the current class
        self.Class="";
        
    # create a state for this problem
    def Create_state(self):
        state=""
        state_Int=[]
        for i in range(0,self.AttributeNumber):
            state+= choice(self.AttributePLausibleValue)
        self.State=state


    # find the corresponding post bits
    def Identify_posbits_Multiplexer(self):
        for number in range(0,len(self.multiplexer_lengths)):
            if self.AttributeNumber==self.multiplexer_lengths[number]:
                self.multiplexer_posbit=self.multiplexer_posbits[number]


    #generate the action for the Multiplexer problem
    def execute_Multiplexer_Action(self):
        place=self.multiplexer_posbit
        for i in range(0,self.multiplexer_posbit):
            if self.State[i]=="1":
                place+=int(math.pow(2.0,float(self.multiplexer_posbit-1-i)))
        self.Class=int(self.State[place])
        

    #generate carray action
    def execute_Carry_Action(self):
        action=0
        half=int(self.AttributeNumber/2)
        for i in range(0,half):
            action=int((action+int(self.State[half-1-i])+ int(self.State[half-1-i+half]))/2)
        self.Class= action


    #execute the majority-on class
    def execute_Majority_On_Action(self):
        count=0
        for i in range(0,self.AttributeNumber):
            if self.State[i]=="1":
                count+=1
        if count> (self.AttributeNumber/2):
            self.Class= 1
        else:
            self.Class= 0

    #randomly generate an sample(state:class)
    def RandomSample(self):
        self.State=""
        self.Create_state()

        if self.ProblemId==0:
            self.execute_Multiplexer_Action()
        elif self.ProblemId==1:
            self.execute_Carry_Action()
        elif self.ProblemId==2:
            self.execute_Majority_On_Action()


    #Initial the plausible values for each attribute
    def Initial_Plausible_Attribute_Values(self):
        for i in range(0,self.AttributeNumber):
            temp=[]
            temp.append("0")
            temp.append("1")
            self.PlausibleAtributeValueList.append(temp)


    #return the reward of this environment
    def GetReward(self,P_Action):
        if self.Class==P_Action:
            return self.Reward
        return 0


    #generate the attribute list
    def Initial_Attribute_List(self):
        for i in range(0,self.AttributeNumber):
            self.AttributeList.append(i)


