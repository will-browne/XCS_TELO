class standard_XCS_config:
    def __init__(self):
        #XCS configure parameters
        self.alpha=0.1 #The fall of rate in the fitness evaluation.

        self.beta=0.2 # The learning rate for updating fitness, prediction, prediction error, and action set size estimate in XCS's classifiers.

        self.gama=0.95 # The discount raye in multi-step problems

        self.delta=0.1 #The fraction of the mean fitness of the population below which the fitness of a classifier may be considered in its vote for deletion.

        self.nu=5 #Specifies the exponent in the power function for the fitness evaluation

        self.theta_GA=25.0#The threshold for the GA application in an action set.

        self.epsilon_0=10.0#The error threshold under which the accuracy of a classifier is set to one.

        self.theta_del=20#Specified the threshold over which the fitness of a classifier may be considered in its deletion probability.

        self.pX=0.8#The probability of mutating one allele and the action in an offspring classifier

        self.crossoverType=2 #0 uniform, 1 onePoint, and 2 twopoint crossover.

        self.pM=0.04 # The probability of mutating one allele and the action in an offerspring classifier.

        self.mutationType =0 #0 niche and 1 general mutation

        self.P_dontcare =0.3 #The probability of using a don't care symbol in an allele when covering

        self.predictionErrorReduction=1.0#0.25 The reduction of the prediction error when generating an offspring classifier.

        self.fitnessReduction=0.1 #The reduction of the fitness when generating an offspring classifier.

        self.theta_sub=20 # The experience of a classifier required to be a subsumer

        self.predictionIni=10.0 #The initial prediction value when geneerating a new classifier (e.g in covering).

        self.predictionErrorIni=0.0 #The initial prediction error value when generating a new classifier (e.g in cvering)

        self.fitnessIni=0.01 # The initial fitness value when generating a new classifier (e.g in covering)

        self.doGASubsumption =True # specifies if GA subsumption should be executed.

        self.doActSetSubsumption =False #True specifies if action set subsumption should be executed

        self.tournametSize =0.4 #The fraction of classifiers participating in a tournament from an action set.

        self.forceDifferentInTournament=0.0

        self.doGAErrorBasedSelect=False

        self.selecTolerance=0.05

        self.dontcare='#' #The don't care symbol (normally '#')
