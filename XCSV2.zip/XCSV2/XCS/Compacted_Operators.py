
class Compacted_Operator:

    #read the information from a given address
    def __Read_Information(self,address):
        read_information=open(address,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n' and ":" in lines:
             information.append(lines)

        return information

    def __create_rule(self,condition,action):
        rule=[]
        rule.append(condition)
        rule.append(action)
        return rule


    def Read(self,address):
        informations=self.__Read_Information(address)
        result=[]
        for raw in informations:
            extracted= raw.split('\n')[0].split(' :')
            action=int(extracted[1].split(' ')[-1])
            condition=extracted[0].split(' ')[0:-1]
            for i in range(0,len(condition)):
                if condition[i]!='#':
                    if not '.' in condition[i]:
                        condition[i]=int(condition[i])
                    else:
                        condition[i]=float(condition[i])
            rule=self.__create_rule(condition,action)
            result.append(rule)
        print(len(result))
        return result

    def count_dontcare(self,rule):
        count=0
        for i in range(0,len(rule[0])):
            if rule[0][i]=='#':
                count+=1
        return count

    def count_one(self,rule):
        count=0
        for i in range(0,len(rule[0])):
            if rule[0][i]==1:
                count+=1
        return count

    def count_zero(self,rule):
        count=0
        for i in range(0,len(rule[0])):
            if rule[0][i]==0:
                count+=1
        return count


class Compacted_Operator_OldXCS:

    #read the information from a given address
    def __Read_Information(self,address):
        read_information=open(address,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)

        return information

    def __create_rule(self,condition,action):
        rule=[]
        rule.append(condition)
        rule.append(action)
        return rule


    def Read(self,address):
        informations=self.__Read_Information(address)
        result=[]
        for raw in informations:
            extracted= raw.split(" ----> ")[0].split(" : ")
            action=int(extracted[-1])
            condition=extracted[0]
            outCondition=[]
            for i in range(0,len(condition)):
                if condition[i]!='#':                    
                    outCondition.append(int(condition[i]))
                else:
                    outCondition.append('#')

           
            rule=self.__create_rule(outCondition,action)
            result.append(rule)
        return result

    def count_dontcare(self,rule):
        count=0
        for i in range(0,len(rule[0])):
            if rule[0][i]=='#':
                count+=1
        return count

    def count_one(self,rule):
        count=0
        for i in range(0,len(rule[0])):
            if rule[0][i]==1:
                count+=1
        return count

    def count_zero(self,rule):
        count=0
        for i in range(0,len(rule[0])):
            if rule[0][i]==0:
                count+=1
        return count


class Compacted_Operator_UCS:

    #read the information from a given address
    def __Read_Information(self,address):
        read_information=open(address,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)

        return information

    def __create_rule(self,condition,action):
        rule=[]
        rule.append(condition)
        rule.append(action)
        return rule


    def Read(self,address):
        informations=self.__Read_Information(address)
        result=[]
        for raw in informations:
            extracted= raw.split(" ->")
            action=int(extracted[-1].split(" ")[0])
            condition=extracted[0].split(" ")
            for i in range(0,len(condition)):
                if condition[i]!='#':                    
                    condition[i]=int(condition[i])


           
            rule=self.__create_rule(condition,action)
            result.append(rule)
        return result

    def count_dontcare(self,rule):
        count=0
        for i in range(0,len(rule[0])):
            if rule[0][i]=='#':
                count+=1
        return count

    def count_one(self,rule):
        count=0
        for i in range(0,len(rule[0])):
            if rule[0][i]==1:
                count+=1
        return count

    def count_zero(self,rule):
        count=0
        for i in range(0,len(rule[0])):
            if rule[0][i]==0:
                count+=1
        return count

class Compacted_Operator_ASCS:

    #read the information from a given address
    def __Read_Information(self,address):
        read_information=open(address,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n' and"--->" in lines:
             information.append(lines)

        return information

    def __create_rule(self,condition,action):
        rule=[]
        rule.append(condition)
        rule.append(action)
        return rule


    def Read(self,address):
        informations=self.__Read_Information(address)
        result=[]
        for raw in informations:
            extracted= raw.split(" :  ")[0].split(" ---> ")
            action=int(extracted[-1])
            condition=extracted[0].split(" ")
            for i in range(0,len(condition)):
                if condition[i]!='#':                    
                    condition[i]=int(condition[i])


           
            rule=self.__create_rule(condition,action)
            #print(rule)
            result.append(rule)
        return result

    def count_dontcare(self,rule):
        count=0
        for i in range(0,len(rule[0])):
            if rule[0][i]=='#':
                count+=1
        return count

    def count_one(self,rule):
        count=0
        for i in range(0,len(rule[0])):
            if rule[0][i]==1:
                count+=1
        return count

    def count_zero(self,rule):
        count=0
        for i in range(0,len(rule[0])):
            if rule[0][i]==0:
                count+=1
        return count

class Compacted_Model:
    def __Read_Information(self,address):
        read_information=open(address,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n' and":" in lines:
             information.append(lines)

        return information

    def __create_rule(self,condition,action,prediction):
        rule=[]
        rule.append(condition)
        rule.append(action)
        rule.append(prediction)
        return rule


    def Read(self,address):
        informations=self.__Read_Information(address)
        result=[]
        for raw in informations:
            extracted= raw.split("  : ")
            inform=extracted[1].split("\n")[0].split(" ")
            action=int(inform[0])
            prediction=float(inform[1])
            condition=extracted[0].split(" ")
            for i in range(0,len(condition)):
                if condition[i]!='#':                    
                    condition[i]=condition[i]


           
            rule=self.__create_rule(condition,action,prediction)
            #print(rule)
            result.append(rule)
        print(len(result))
        return result

    def count_dontcare(self,rule):
        count=0
        for i in range(0,len(rule[0])):
            if rule[0][i]=='#':
                count+=1
        return count

    def count_one(self,rule):
        count=0
        for i in range(0,len(rule[0])):
            if rule[0][i]==1:
                count+=1
        return count

    def count_zero(self,rule):
        count=0
        for i in range(0,len(rule[0])):
            if rule[0][i]==0:
                count+=1
        return count

