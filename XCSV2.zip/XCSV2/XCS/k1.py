from XCS_Operators import XCS_Operators
from RealEnvironment import RealEnvironment
from RepresentationSybolistTernary import RepresentationSymbolistTernary
import copy


#implement the CRA2
class K1:
    def __init__(self,population,env,oper,rep):
        #environment
        self.env=env

        #the name of the algorithm
        self.Name="k1"


        #system operator
        self.oper=oper

        #a population based on list format
        self.population=population

        #a representation format
        self.rep=rep

        #predict accuracy
        self.accuracy=0

        self.Compacted_Population=[]

        self.__K1_Implement()

    def __getMatchSet(self,population):
        match_set=[]
        #print "begin"
        for i in range(0,len(population)):
            #0: condition (encoding)
            if(self.rep.Match(population[i][0])):
                #add matching classifier to the matchset
                match_set.append(i)
        return match_set


    def __AccuracyTest(self,population):
        correct=0.0
        #the number of instances need to be reviewed
        while self.env.Next()!=True:
            M=self.__getMatchSet(population)
            P_action=self.__Prediction(M,population)
            if self.env.Class==P_action:
                correct+=1
        accu=correct/(self.env.instanceNumber+1)
        return accu


    def __Prediction(self,match_set,population):
        actions_value=[]
        for i in range(0,self.env.NumberClasses):
            actions_value.append(0)

        for id in match_set:
             actions_value[population[id][1]]+=self.oper.GetPredictValue(population[id])

        #deault maxi
        max_id=0
        max_value=actions_value[0]
        for i in range(1,self.env.NumberClasses):
            if actions_value[i]>max_value:
                max_value=actions_value[i]
                max_id=i
        if len(match_set)==0:
            max_id=None
        return max_id


    def __print_population(self,population):
        for rule in population:
            print(rule)

    #add additional column
    def __Add_additional_column_list(self,population):
        for rule in population:
            rule.append(0)
            rule.append(0)
       

     #review the training_set
    def __Review_all_train_instance(self,population):
        self.__Add_additional_column_list(population)
        #the number of instances need to be reviewed
        while self.env.Next()!=True:
            M=self.__getMatchSet(population)
            for id in M:
                #record the number of matched instance with the same action
                if population[id][1]==self.env.Class:
                    population[id][-1]+=1
                else:
                    #record the number of matched instance with the different action
                    population[id][-2]+=1



    def __K1_Implement(self):
        selected_ids=[]

        while self.env.Next()!=True:
            M=self.__getMatchSet(self.population)
            C_Set=[]
            #form the correct id
            for id in M:
                #1 action
                if self.population[id][1]==self.env.Class:
                    C_Set.append(id)

            best_score=-100
            best_Id=None

            for c_id in C_Set:

                
                score=1.0*(self.population[c_id][-1]-self.population[c_id][-2])/(self.env.instanceNumber+1)
                if score>best_score:
                    best_score=score
                    best_Id=c_id

            if best_Id!=None: 
                if not best_Id in selected_ids:
                   selected_ids.append(best_Id)

        c_population=[]
        for id in selected_ids:
            c_population.append(self.population[id])

        self.accuracy=self.__AccuracyTest(c_population)
        self.Compacted_Population=c_population

        self.__print_population(self.Compacted_Population)
        print("final accuracy",self.accuracy)
