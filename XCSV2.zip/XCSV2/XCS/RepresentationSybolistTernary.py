from Encoding import Encoding
import random
from random import choice

class RepresentationSymbolistTernary(Encoding):

    def __init__(self,env,config):

        #the invoked environment
        self.env=env

        #a fconfig document
        self.config=config


    #if the rate less than don't care probability, then set an attribute with don't care symbol
    # return a new classifier and its relevant generalization level
    def CreateCondition(self):
        encoding=[]
        
        for i in range(0,self.env.AttributeNumber):
            if(random.random()<self.config.P_dontcare):
                encoding.append(self.config.dontcare)
                
            else:
                encoding.append(self.env.State[i])

        #generalization level
        count=self.Generalization_level(encoding)
        return encoding, count


    #judge whether a rule's encoding can match an environmental state
    def Match(self, encoding):
        for i in range(0,self.env.AttributeNumber):
            if encoding[i]!=self.config.dontcare and encoding[i]!=self.env.State[i]and self.env.State[i]!=self.config.dontcare:
                return False
        return True


    #two-point crossover
    #apply the two points crossover to two encodings
    def twoPointsCrossover(self,encoding1, encoding2):
        #find the two points for crossover
        point_1=random.randint(0,self.env.AttributeNumber-1)
        point_2=random.randint(0,self.env.AttributeNumber-1)
        #rank the points ascending according to its value
        if point_1>point_2:
            help=point_1
            point_1=point_2
            point_2=help

        for i in range(point_1,point_2+1):
            help=encoding1[i]
            encoding1[i]=encoding2[i]
            encoding2[i]=help

    #niche mutation
    def NicheMutation(self,encoding):
        for i in range(0,self.env.AttributeNumber):
            if random.random()<self.config.pM:
                if encoding[i]==self.config.dontcare:
                    encoding[i]=self.env.State[i]
                else:
                    encoding[i]=self.config.dontcare


    #action mutation
    def ActionMutation(self,action):
        mutated_action=action
        if random.random()<self.config.pM:
             while mutated_action==action:
                 mutated_action=random.choice(self.env.PlausibleClassesId)
        return mutated_action


    #count generalization level
    def Generalization_level(self,encoding):
        count=0
        for i in range(0,self.env.AttributeNumber):
            if encoding[i]==self.config.dontcare:
                count+=1
        return count


    #check whether this encoding1 is more general than enconding2
    def IsMoreGeneral(self,encoding1,encoding2):
        for i in range(0,self.env.AttributeNumber):
            if (encoding1[i]!=self.config.dontcare) and (encoding1[i]!=encoding2[i]):
                return False
        return True


    #judge whether two encodings are the same
    def IsSameEncoding(self,encoding1,encoding2):
        for i in range(0,self.env.AttributeNumber):
            if encoding1[i]!=encoding2[i]:
                return False
        return True


    #convert enconding to string
    def EncodingString(self,enconding):
       result=""
       for i in enconding:
           result+= str(i)+" "
       return result


    #judge whether an encoding match an state:
    def MatchState(self,encoding,state):
       for i in range(0,self.env.AttributeNumber):
            if encoding[i]!=self.config.dontcare and encoding[i]!=state[i]:
                return False
       return True

    #check whether two rule conflit
    def Conflit(self,condition_1, condition_2):
        for i in range(0,len(condition_1)):
            if condition_1[i] !='#' and condition_2[i]!='#' and condition_1[i]!=condition_2[i]:
                return False
        return True