import copy
import math
from RealEnvironment import RealEnvironment

class RCR3:

    def __init__(self,populations,env,oper,rep):
        #environment
        self.env=env

        #the name of the algorithm
        self.Name="RCR3"

        #system operator
        self.oper=oper

        #a population based on list format
        self.populations=populations

        #a representation format
        self.rep=rep

        #control the percentage of selected rules in the Micro Razor
        self.superior_percent=0.6

        #predict accuracy
        self.accuracy=0

        self.Compacted_Population=[]

        self.Active_Error_Detector=True
        #implement the RCR2
        self.__ImplementRCR3(env)


    ##Accuracy test ##############
    def __getMatchSet(self,population):
        match_set=[]
        #print "begin"
        for i in range(0,len(population)):
            #0: condition (encoding)
            if(self.rep.Match(population[i][0])):
                #add matching classifier to the matchset
                match_set.append(i)
        return match_set

    def __AccuracyTest(self,population):
        correct=0.0
        #the number of instances need to be reviewed
        while self.env.Next()!=True:
            M=self.__getMatchSet(population)
            P_action=self.__Prediction(M,population)
            if self.env.Class==P_action:
                correct+=1
        accu=correct/(self.env.instanceNumber+1)
        return accu


    def __Prediction(self,match_set,population):
        actions_value=[]
        for i in range(0,self.env.NumberClasses):
            actions_value.append(0)

        for id in match_set:
             actions_value[population[id][1]]+=self.oper.GetPredictValue(population[id])

        #deault maxi
        max_id=0
        max_value=actions_value[0]
        for i in range(1,self.env.NumberClasses):
            if actions_value[i]>max_value:
                max_value=actions_value[i]
                max_id=i
        if len(match_set)==0:
            max_id=None
        return max_id

    def __AccuracyTestRecord(self,population):
        correct=0.0
        #the number of instances need to be reviewed
        while self.env.Next()!=True:
            M=self.__getMatchSet(population)
            P_action=self.__Prediction(M,population)
            if self.env.Class==P_action:
                correct+=1

            for id in M:
                if population[id][1]==self.env.Class:
                    #correct
                    population[id][-3]+=1
                else:
                    #incorrect
                    population[id][-2]+=1
        accu=correct/(self.env.instanceNumber+1)
        return accu

    ########################################################
    ############            Diversity Razor        #########
    ########################################################

    #add additional column
    def __Add_additional_column_count(self,population):
        #return the sum of the product
        for rule in population:
            #-3 correct match
            #-2 incorrect match
            #-1 Map list
            correct=0
            incorrect=0 
            temp=[]          
            rule.append(correct)
            rule.append(incorrect)
            rule.append(temp)

    def __Razor_Accuracy(self,population):
        remove_list=[]


        for id in range (0,len(population)):
            # -2 incorrect -3 correct
            if population[id][-2] * population[id][-3]!=0 or population[id][-2]+population[id][-3]==0:
                remove_list.append(id)



        count=0

        for id in remove_list:
            population.pop(id-count)
            count+=1

    def __Implement_Diversity_Razor(self,populations):
        for population in populations:
            self.__Add_additional_column_count(population)
            self.__AccuracyTestRecord(population)
            self.__Razor_Accuracy(population)

    ########################################################
    ############           Cluster                 #########
    ########################################################
    #judge whether two rules are the same
    def __Is_Same_Rule(self,Rule1,Rule2):
        #check the action
        if Rule1[1]!=Rule2[1]:
            return False
        else:
            #condition 0
            if self.rep.IsSameEncoding(Rule1[0],Rule2[0]):
                return True
            else:
                return False

    #initial the cluster
    def __Initial_Cluster(self):
        cluster=[]
        for i in range(0,self.env.AttributeNumber+1):
            p=[]
            cluster.append(p)
        return cluster

    def __Is_Exist_Level(self,cluster,rule):
        for id in range(0,len(cluster)):
            if self.__Is_Same_Rule(cluster[id],rule):
                return id
        return None

    def __Cluster(self,Populations_Set):
        
        #need to be extend if implement the UCS
        P_cluster=self.__Initial_Cluster()
        N_cluster=self.__Initial_Cluster()

        PredictionId=self.oper.GetPredictionId()
        numerosityId=self.oper.GetNumerosityID()
        experienceID=self.oper.GetExperienceId()
        for population in Populations_Set:
            for rule in population:
                #0 condition
                if rule[PredictionId]==1000:
                    self.__ClusterAdd(P_cluster,rule,numerosityId,experienceID)
                elif rule[PredictionId]==0:
                    self.__ClusterAdd(N_cluster,rule,numerosityId,experienceID)


                
        return P_cluster, N_cluster

    def __ClusterAdd(self, cluster,rule,numerosityId,experienceID):
        level=self.rep.Generalization_level(rule[0])
        id= self.__Is_Exist_Level(cluster[level],rule)
        if id !=None:
              
              cluster[level][id][numerosityId]+=rule[numerosityId]
              cluster[level][id][experienceID]+=rule[experienceID]
        else:
              cluster[level].append(rule)

    def __print_cluster(self,clusters):
        for id in range(0,len(clusters)):
            print(id,"=======================")
            for rule in clusters[id]:
                print(rule)

   ###################################################################
   ############            Razor in Polymorphism             #########
   ###################################################################

    def __Subsumption(self,cluster):

         for level in range(len(cluster)-1,0,-1):
             for g_rule in cluster[level]:
                 
                 for C_level in range(level-1,-1,-1):
                     remove_list=[]
                     for S_id in range(0,len(cluster[C_level])):
                         if g_rule[1]==cluster[C_level][S_id][1]:
                            #0 condition
                            if self.rep.IsMoreGeneral(g_rule[0],cluster[C_level][S_id][0]):
                                remove_list.append(S_id)
                     count=0
                     for r_id in remove_list:
                         cluster[C_level].pop(r_id-count)
                         count+=1

    def __MatchList_Generator(self,cluster):
        id=0
        while self.env.Next()!=True:
            for i in range(0,len(cluster)):
                for rule in cluster[i]:
                    if(self.rep.Match(rule[0])):
                        #match list -1
                        rule[-1].append(id)
            id+=1

    def __Initial_PresentList(self,env):
        result=[]
        for i in range(0,env.NumberClasses):
            temp=[]
            result.append(temp)
        return result

    def __Merge_Process(self,cluster,env):
        Present_list=self.__Initial_PresentList(env)
        
        for i in range(len(cluster)-1,-1,-1):
            remove_list=[]
            for rule_id in range(0,len(cluster[i])):
                remove=True
                #-1 match list
                for id in cluster[i][rule_id][-1]:
                    #1 action
                    if not id in Present_list[cluster[i][rule_id][1]]:
                        Present_list[cluster[i][rule_id][1]].append(id)
                        remove=False
                if remove:
                    remove_list.append(rule_id)

            count=0
            for dele in remove_list:
                cluster[i].pop(dele-count)
                count+=1

    def __Create_Population(self,cluster,population):
        for i in range(0,len(cluster)):
                for rule in cluster[i]:
                    population.append(rule)

    def __Polymorphism_Razor(self,support_cluster,opposite_cluster,env):
        self.__Subsumption(support_cluster)
        self.__Subsumption(opposite_cluster)
        self.__MatchList_Generator(support_cluster)
        self.__MatchList_Generator(opposite_cluster)
        self.__Merge_Process(support_cluster,env)
        self.__Merge_Process(opposite_cluster,env)
        population=[]

        self.__Create_Population(support_cluster,population)
        self.__Create_Population(opposite_cluster,population)
        return population

    def __print_population(self,population):
        for rule in population:
            print(rule)

    def __ImplementRCR3(self, env):
        self.__Implement_Diversity_Razor(self.populations)
        support_cluster,opposite_cluster=self.__Cluster(self.populations)

        result=self.__Polymorphism_Razor(support_cluster,opposite_cluster,env)
        self.Compacted_Population=result
        self.accuracy= self.__AccuracyTest(result)
        
        self.__print_population(self.Compacted_Population)
        print(self.accuracy)
