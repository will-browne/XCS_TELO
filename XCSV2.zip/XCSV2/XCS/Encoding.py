class Encoding(object):

    def IsSameEncoding(rule1,rule2):
        print("Judge Whether two rules have the same enconding")


    def IsMoreGeneral(rule1,rule2):
        print("Judge whether rule1 can subsume rule2, if success return True, else return wrong")


    def CreateCondition(state):
        print("create a new condition the cover this state")


    def Match(rule,state):
        print("Judge whether this rule can cover this state")





