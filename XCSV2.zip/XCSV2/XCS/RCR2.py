import copy
import math
from XCS_Operators import XCS_Operators
from RealEnvironment import RealEnvironment
from RepresentationSybolistTernary import RepresentationSymbolistTernary

class RCR2:
    def __init__(self,populations,env,oper,rep):
        #environment
        self.env=env

        #the name of the algorithm
        self.Name="RCR2"

        #system operator
        self.oper=oper

        #a population based on list format
        self.populations=populations

        #a representation format
        self.rep=rep

        #control the percentage of selected rules in the Micro Razor
        self.superior_percent=0.6

        #predict accuracy
        self.accuracy=0

        self.Compacted_Population=[]

        #whether active the error detector
        self.Active_Error_Detector=False

        #implement the RCR2
        self.__ImplementRCR2()

    ##Accuracy test ##############
    def __getMatchSet(self,population):
        match_set=[]
        #print "begin"
        for i in range(0,len(population)):
            #0: condition (encoding)
            if(self.rep.Match(population[i][0])):
                #add matching classifier to the matchset
                match_set.append(i)
        return match_set

    def __AccuracyTest(self,population):
        correct=0.0
        #the number of instances need to be reviewed
        while self.env.Next()!=True:
            M=self.__getMatchSet(population)
            P_action=self.__Prediction(M,population)
            if self.env.Class==P_action:
                correct+=1
        accu=correct/(self.env.instanceNumber+1)
        return accu


    def __Prediction(self,match_set,population):
        actions_value=[]
        for i in range(0,self.env.NumberClasses):
            actions_value.append(0)

        for id in match_set:
             actions_value[population[id][1]]+=self.oper.GetPredictValue(population[id])

        #deault maxi
        max_id=0
        max_value=actions_value[0]
        for i in range(1,self.env.NumberClasses):
            if actions_value[i]>max_value:
                max_value=actions_value[i]
                max_id=i
        if len(match_set)==0:
            max_id=None
        return max_id

    ########################################################
    ############            Diversity Razor        #########
    ########################################################

    #remove the inacuracy rules
    def __Razor_Accuracy(self,population):
        remove_list=[]

        for id in range (0,len(population)):
            accuracyId=self.oper.GetAccuracyId()
            #3 accuracy XCS
            if population[id][accuracyId]<1.0:
                    remove_list.append(id)

        count=0
        for id in remove_list:
            population.pop(id-count)
            count+=1

    #Macro razor
    def __Implement_Diversity_Razor(self,populations):
        subsets=[]
        for population in populations:
            print(self.__AccuracyTest(population))
            self.__Razor_Accuracy(population)
            
            subsets.append(population)
        return subsets

    ########################################################
    ############           Cluster                 #########
    ######################################################## 

    #judge whether two rules are the same
    def __Is_Same_Rule(self,Rule1,Rule2):
        #check the action
        if Rule1[1]!=Rule2[1]:
            return False
        else:
            #condition 0
            if self.rep.IsSameEncoding(Rule1[0],Rule2[0]):
                return True
            else:
                return False

    #initial the cluster
    def __Initial_Cluster(self):
        cluster=[]
        for i in range(0,self.env.AttributeNumber+1):
            p=[]
            cluster.append(p)
        return cluster

    def __Is_Exist_Level(self,cluster,rule):
        for id in range(0,len(cluster)):
            if self.__Is_Same_Rule(cluster[id],rule):
                return id
        return None

    def __Cluster(self,Populations_Set):
        
        #need to be extend if implement the UCS
        P_cluster=self.__Initial_Cluster()
        N_cluster=self.__Initial_Cluster()

        PredictionId=self.oper.GetPredictionId()
        numerosityId=self.oper.GetNumerosityID()
        experienceID=self.oper.GetExperienceId()
        for population in Populations_Set:
            for rule in population:
                #0 condition
                if rule[PredictionId]==1000:
                    self.__ClusterAdd(P_cluster,rule,numerosityId,experienceID)
                elif rule[PredictionId]==0:
                    self.__ClusterAdd(N_cluster,rule,numerosityId,experienceID)


                
        return P_cluster, N_cluster

    def __ClusterAdd(self, cluster,rule,numerosityId,experienceID):
        level=self.rep.Generalization_level(rule[0])
        id= self.__Is_Exist_Level(cluster[level],rule)
        if id !=None:
              
              cluster[level][id][numerosityId]+=rule[numerosityId]
              cluster[level][id][experienceID]+=rule[experienceID]
        else:
              cluster[level].append(rule)

    def __print_cluster(self,clusters):
        for id in range(0,len(clusters)):
            print(id,"=======================")
            for rule in clusters[id]:
                print(rule)

    ###################################################################
    ############            Razor in Polymorphism             #########
    ###################################################################

    #initial the error list
    def __Initial_Error_List_Outer(self):
        result=[]
        
        for i in range(0,self.env.AttributeNumber+1):
            temp=[]
            result.append(temp)
        return result

    def __Error_Detection_Validation(self,cluster):
        # initial the error list
        error_list=self.__Initial_Error_List_Outer()
        experienceId=self.oper.GetExperienceId()
        for i in range(1,len(cluster)):
            # judge wether is unvalied
            
            for rule_h in range(0,len(cluster[i])):
                #using error score or not
                error_score=0


                for j in range(0,i+1): 
                    if  rule_h in error_list[i]: 
                        break
                    else:       
                        for rule_l in range(0,len(cluster[j])):
                            if not rule_l in error_list[j]:
                                #same action 1
                                #rule have differenct actions
                                if cluster[i][rule_h][1] != cluster[j][rule_l][1]:
                                    if self.rep.Conflit(cluster[i][rule_h][0],cluster[j][rule_l][0]):
                                                error_score+=cluster[j][rule_l][experienceId]
                                                if error_score>cluster[i][rule_h][experienceId]:
                                                
                                                    error_list[i].append(rule_h)
                                                    break

                                            


        for i in range(1,len(error_list)):
            if len(error_list[i])!=0:
                count=0
                del_list=copy.deepcopy(error_list[i])
                del_list.sort()
                for dele in del_list:
                    cluster[i].pop(dele-count)
                    count+=1

    def __Error_Detection_Exclude(self,cluster):
        # initial the error list
        error_list=self.__Initial_Error_List_Outer()
        experienceId=self.oper.GetExperienceId()
        for i in range(0,len(cluster)-1):
            # judge wether is unvalied
            
            for rule_h in range(0,len(cluster[i])):
                #using error score or not
                error_score=0


                for j in range(i,len(cluster)): 
                    if  rule_h in error_list[i]: 
                        break
                    else:       
                        for rule_l in range(0,len(cluster[j])):
                            if not rule_l in error_list[j]:
                                #same action 1
                                #6 critical state of gener explore state
                                if cluster[i][rule_h][1] != cluster[j][rule_l][1]:
                                    if self.rep.Conflit(cluster[i][rule_h][0],cluster[j][rule_l][0]):   
                                                error_score+=cluster[j][rule_l][experienceId]
                                                if error_score>cluster[i][rule_h][experienceId]:
                                                    error_list[i].append(rule_h)
                                                    break
                                            
        for i in range(1,len(error_list)):
            if len(error_list[i])!=0:
                count=0
                del_list=copy.deepcopy(error_list[i])
                del_list.sort()
                for dele in del_list:
                    cluster[i].pop(dele-count)
                    count+=1

    def __Subsumption(self,cluster):

         for level in range(len(cluster)-1,0,-1):
             for g_rule in cluster[level]:
                 
                 for C_level in range(level-1,-1,-1):
                     remove_list=[]
                     for S_id in range(0,len(cluster[C_level])):
                         #1 action
                         if g_rule[1]==cluster[C_level][S_id][1]:
                            #0 condition
                            if self.rep.IsMoreGeneral(g_rule[0],cluster[C_level][S_id][0]):
                                remove_list.append(S_id)
                     count=0
                     for r_id in remove_list:
                         cluster[C_level].pop(r_id-count)
                         count+=1

    def __Create_Population(self,cluster,population):
        for i in range(0,len(cluster)):
                for rule in cluster[i]:
                    population.append(rule)


    def __Polymorphism_Razor(self,support_cluster,opposite_cluster):
        if self.Active_Error_Detector:
            self.__Error_Detection_Validation(support_cluster)
            self.__Error_Detection_Validation(opposite_cluster)
            self.__Error_Detection_Exclude(support_cluster)
            self.__Error_Detection_Exclude(opposite_cluster)
        self.__Subsumption(support_cluster)
        self.__Subsumption(opposite_cluster)
        population=[]
        self.__Create_Population(support_cluster,population)
        self.__Create_Population(opposite_cluster,population)
        return population

    def __print_population(self,population):
        for rule in population:
            print(rule)

    def __Initial_PresentList(self,env):
        result=[]
        for i in range(0,env.NumberClasses):
            temp=[]
            result.append(temp)
        return result

    def __ImplementRCR2(self):
        subsets=self.__Implement_Diversity_Razor(self.populations)
        support_cluster,opposite_cluster=self.__Cluster(subsets)

        result=self.__Polymorphism_Razor(support_cluster,opposite_cluster)
        self.Compacted_Population=result
        self.accuracy= self.__AccuracyTest(result)
        
        self.__print_population(self.Compacted_Population)
        print(self.accuracy)
