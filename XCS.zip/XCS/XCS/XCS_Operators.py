from RepresentationSybolistTernary import RepresentationSymbolistTernary
from BooleanEnvironment import BooleanEnvironment
from Classifier import Classifier_XCS
from Config_StandardXCS import standard_XCS_config
from random import choice
import random
import gc
import copy
from decimal import Decimal
import time

class XCS_Operators:

    #initialize a population pool for storing the evolved classifier
    # all the rules advocated the same action are stored in the same population
    # in each population, rules are clustered accprding to the number of generalized attributes
    def Initial_Population(self, AttributeNumber, ClassNumber):
        Population_Pool=[]
        for i in range(0,ClassNumber):
            population=[]
            for j in range(0,AttributeNumber+1):
                Cluster=[]
                population.append(Cluster)
            Population_Pool.append(population)
        return Population_Pool


    def Initial_Stastic(self):
        result=[]
        #sum of rules'numerosity in the population pool (population size)
        result.append(0.0)
        #sum of rules'fitness in the population pool
        result.append(0.0)
        #sum of rules' delete value
        result.append(0.0)
        #sum of unmatched cases
        result.append(0.0)
        return result

    #find the rules in a population pool, which can cover the input instance's state
    def __MatchSet_Detector(self,PopulationPool,Classifier_Operator):
        #the match set 
        MatchSet=[]
        #population in populationpool: a population stores rules advocating the same class
        for p in range(0,len(PopulationPool)):
            Action_Set=[]
            MatchSet.append(Action_Set)

            #clusters in a population
            for c in range(0,len(PopulationPool[p])):
                #rules in a cluster
                for r in range(0,len(PopulationPool[p][c])):
                    if Classifier_Operator.Match(PopulationPool[p][c][r].encoding):
                        #record the matched rule
                        temp=[]
                        temp.append(c)
                        temp.append(r)
                        Action_Set.append(temp)
        return MatchSet

    #create a classifier that can represent the input instance
    def __Covering_state_with_new_rule(self, action, time,config,Classifier_Operator):
        #generate a condition(encoding)
        condition,ClusterId=Classifier_Operator.CreateCondition()
        classifier=Classifier_XCS(condition,action,config.predictionIni,config.predictionErrorIni,config.fitnessIni,config.fitnessIni,time)
        return classifier,ClusterId


    #Cover the unrepresented instances
    #this process aims to represent a instance with any plausible actions, as XCSs are designed to search a complete map
    #Cover usually after the matching
    #all plausible actions must have at least one rule can cover the input instance
    def __Covering(self,MatchSet,time, config, Classifier_Operator, PopulationPool,statistics):
        for action in range(0,len(MatchSet)):
            if len(MatchSet[action])==0:
                classifier, ClusterId=self.__Covering_state_with_new_rule(action,time,config,Classifier_Operator)
                PopulationPool[action][ClusterId].append(classifier)
                #population sum
                statistics[0]+=1
                #fitness sum
                statistics[1]+=classifier.fitness
                #delete weight sum
                statistics[2]+=1



    # the Matching processing of XCS
    def Matching(self,time,PopulationPool,Classifier_Operator,config,statistics):
        #Match set in LCS usually represent by [M]
        M=self.__MatchSet_Detector(PopulationPool,Classifier_Operator)

        #the number of rules in population pool after covering
        self.__Covering(M,time,config,Classifier_Operator,PopulationPool,statistics)

        return M


    #print the trained classifiers (rules)
    def PrintClassifiers(self,PopulationPool):
        for p in range(len(PopulationPool)-1,-1,-1):
            print("Action "+str(p)+" =====================================")
            for c in range(len(PopulationPool[p])-1,-1,-1):
                for r in range(len(PopulationPool[p][c])-1,-1,-1):
                    rule=PopulationPool[p][c][r]
                    print(str(rule.encoding) +" "+str(rule.action)   +" Num "   +  str(int(Decimal(rule.numerosity).quantize(Decimal("0.00")))) +" exp "+ str(rule.experience) 
                          +" Pre "+str(Decimal(rule.prediction).quantize(Decimal("0.00"))) +" EP " + str(Decimal(rule.predictionError).quantize(Decimal("0.00")))     
                          +" Fit " +  str(Decimal(rule.fitness).quantize(Decimal("0.00"))) +" ASS " +  str(Decimal(rule.actionSetSize).quantize(Decimal("0.00")))                                                                      
                          +" Acc " + str(round(rule.accuracy,6))  + " Del "  +   str(rule.deleteWeight)  
                         )
                      


    #randomly select a class for updating the parameters
    def __Randomly_Select_an_Class(self,classList):
        Class= random.choice(classList)
        return Class

    #determine the prediction array out of the match set
    def __GetPredictionArray(self,PopulationPool,MatchSet):
        PredictionArray=[]
        SumFitnessArray=[]
        for action in range(0,len(MatchSet)):
            PredictionArray.append(0.0)
            SumFitnessArray.append(0.0)
            for locat in MatchSet[action]:
                #locat[0]=cluster locat[1]=rule location at cluster
                PredictionArray[action]+=PopulationPool[action][locat[0]][locat[1]].prediction*PopulationPool[action][locat[0]][locat[1]].fitness
                SumFitnessArray[action]+=PopulationPool[action][locat[0]][locat[1]].fitness

            if SumFitnessArray[action]!=0:
                PredictionArray[action]/=SumFitnessArray[action]
        return PredictionArray,SumFitnessArray


    #select the action in the prediction array with the best vote
    #if this instance does not match by any rules return -1 represent the unmatched state
    def __bestActionWinner(self,predictionArray, sumFitnessArray):
        action=0
        for i in range(1,len(predictionArray)):
            if predictionArray[action]<predictionArray[i]:
                action=i
        #this instance is unmatched currently
        if sumFitnessArray[action]==0:
            return -1
        return action


    # Updates all parameters in the action set.
    # Essentially, reinforcement Learning as well as the fitness evaluation takes place in this set.
    # Moreover, the prediction error and the action set size estimate is updated. Also,
    # action set subsumption takes place if selected. As in the algorithmic description, the fitness is updated
    # after prediction and prediction error. However, in order to be more conservative the prediction error is
    # updated before the prediction.
    # @param maxPrediction The maximum prediction value in the successive prediction array (should be set to zero in single step environments).
    # @param reward The actual resulting reward after the execution of an action.
    def __updateActionSet(self,statistics,reward,population,ActionSet,config):
        #none rule need to be updated
        if len(ActionSet)==0:
            return 

        SetSize=0.0

        #update the experience, in passing calculating the size of the action set 
        for locat in ActionSet:
            #locat[0]: cluster, locat[1]: rule id
            population[locat[0]][locat[1]].experience+=1
            SetSize+=population[locat[0]][locat[1]].numerosity


        #update prediction, prediction error and esitimat the action set size
        for locat in ActionSet:
            if population[locat[0]][locat[1]].experience<(1.0/config.beta):
                #prediction error
                population[locat[0]][locat[1]].predictionError= (population[locat[0]][locat[1]].predictionError*(population[locat[0]][locat[1]].experience -1.0)+abs(reward- population[locat[0]][locat[1]].prediction))/population[locat[0]][locat[1]].experience
                #prediction
                population[locat[0]][locat[1]].prediction= (population[locat[0]][locat[1]].prediction* (population[locat[0]][locat[1]].experience -1.0 )+reward)/population[locat[0]][locat[1]].experience
                #action set size
                population[locat[0]][locat[1]].actionSetSize=((
                    population[locat[0]][locat[1]].actionSetSize*(population[locat[0]][locat[1]].experience -1.0)+SetSize)/
                    population[locat[0]][locat[1]].experience)
            else:
                #prediction error
                population[locat[0]][locat[1]].predictionError+= config.beta*(abs(reward-population[locat[0]][locat[1]].prediction)- population[locat[0]][locat[1]].predictionError)
                #prediction
                population[locat[0]][locat[1]].prediction+=config.beta*(reward-population[locat[0]][locat[1]].prediction)
                #action set size
                population[locat[0]][locat[1]].actionSetSize+=config.beta*(SetSize-population[locat[0]][locat[1]].actionSetSize)

        #sum of the product of accuracy and numerosity
        ksum=0.0
        #update accuracy
        for locat in ActionSet:
            if population[locat[0]][locat[1]].predictionError<=config.epsilon_0:
                population[locat[0]][locat[1]].accuracy=1.0
            else:
                population[locat[0]][locat[1]].accuracy= config.alpha*pow(population[locat[0]][locat[1]].prediction/config.epsilon_0,-(config.nu))
            ksum+=population[locat[0]][locat[1]].accuracy*population[locat[0]][locat[1]].numerosity

        #update the fitness
        for locat in ActionSet:
            if ksum==0:
                #sub the old fitness value
                statistics[1]-=population[locat[0]][locat[1]].fitness
                population[locat[0]][locat[1]].fitness-=config.beta*population[locat[0]][locat[1]].fitness
                #add the new fitness value
                statistics[1]+=population[locat[0]][locat[1]].fitness
            else:
                #sub the old fitness value
                statistics[1]-=population[locat[0]][locat[1]].fitness
                population[locat[0]][locat[1]].fitness+=config.beta*(population[locat[0]][locat[1]].accuracy*population[locat[0]][locat[1]].numerosity/ksum- population[locat[0]][locat[1]].fitness)
                #add the new fitness value
                statistics[1]+=population[locat[0]][locat[1]].fitness

        #update the delete weight
        #meanf=SumFitness/SumNumerosity
        meanf=statistics[1]/statistics[0]

        for locat in ActionSet:
            average_fitness=population[locat[0]][locat[1]].fitness/population[locat[0]][locat[1]].numerosity
            if average_fitness>=config.delta*meanf or population[locat[0]][locat[1]].experience< config.theta_del:
                #sub the old delete weight
                statistics[2]-= population[locat[0]][locat[1]].deleteWeight
                population[locat[0]][locat[1]].deleteWeight= population[locat[0]][locat[1]].actionSetSize*population[locat[0]][locat[1]].numerosity
                #add the new delete weight
                statistics[2]+= population[locat[0]][locat[1]].deleteWeight
            else:
                statistics[2]-= population[locat[0]][locat[1]].deleteWeight
                population[locat[0]][locat[1]].deleteWeight= population[locat[0]][locat[1]].actionSetSize*population[locat[0]][locat[1]].numerosity*meanf/average_fitness
                statistics[2]+= population[locat[0]][locat[1]].deleteWeight



    #randomly select an action, and then update the training parameters for each rule in the action set
    def UpdateRandomActionSet(self,populationpool,env,MatchSet,config,statistics):
        R_Action=self.__Randomly_Select_an_Class(env.PlausibleClassesId)
        reward=env.GetReward(R_Action)
        self.__updateActionSet(statistics,reward,populationpool[R_Action],MatchSet[R_Action],config)
        return R_Action


    ############################ discovery mechanism #########################################
    #selects a classifier from 'set' using tourment selection
    #If 'notMe' is not the Null and forceDifferentInTournament is set to a value larger 0,
    # this classifier is not selected except if it is the only classifier.

    #select a classifier from action set using tourment selection
    def __selectClassifierUsingTournamentSelection(self,population,ActionSet, config):

        #if the action set only possess one rule
        if len(ActionSet)==1:
            return ActionSet[0]

        winnerSet=[]
        fitness=-1.0

        #tournament with fixed size
        #select the rule have the highest fitness/numerosity
        while len(winnerSet)==0:
            for i in range(0, len(ActionSet)):
                if len(winnerSet)==0 or (fitness- config.selecTolerance) <=  (population[ActionSet[i][0]][ActionSet[i][1]].fitness/population[ActionSet[i][0]][ActionSet[i][1]].numerosity):
                    for j in range(0,population[ActionSet[i][0]][ActionSet[i][1]].numerosity):
                        if random.random()<config.tournametSize:
                            if len(winnerSet)==0:
                                winnerSet.append(i)
                                fitness=population[ActionSet[i][0]][ActionSet[i][1]].fitness/population[ActionSet[i][0]][ActionSet[i][1]].numerosity
                            else:
                                
                                if(population[ActionSet[i][0]][ActionSet[i][1]].fitness/population[ActionSet[i][0]][ActionSet[i][1]].numerosity)>=(fitness-config.selecTolerance) and (
                                    population[ActionSet[i][0]][ActionSet[i][1]].fitness/population[ActionSet[i][0]][ActionSet[i][1]].numerosity) <=(fitness+config.selecTolerance):
                                    winnerSet.append(i)

                                elif (population[ActionSet[i][0]][ActionSet[i][1]].fitness/population[ActionSet[i][0]][ActionSet[i][1]].numerosity) >(fitness+config.selecTolerance):
                                    winnerSet=[]
                                    winnerSet.append(i)
                                    fitness=population[ActionSet[i][0]][ActionSet[i][1]].fitness/population[ActionSet[i][0]][ActionSet[i][1]].numerosity
                            break;

        #if there is more than one candidate
        if len(winnerSet)>1:           
            Parent= ActionSet[ random.choice(winnerSet)]
        else:
            Parent=ActionSet[winnerSet[0]]

        #clean the garbage
        del winnerSet[:]


        return Parent


    #Judge whether this rule already exist in the population
    def __SameRule(self,population,encoding,clusterId,Classifier_Operator,statstics):
        for rule in population[clusterId]:
            if Classifier_Operator.IsSameEncoding(rule.encoding,encoding):
                rule.numerosity+=1
                return True
        return False


    #Judge whether this rule can subsume other rules
    def __SubsumeRule(self,population,encoding,clusterId,Classifier_Operator,env, config,statstics ):
        #a rule is highest generalized must cannot be subsumed by other rules
        if clusterId==env.AttributeNumber:
            return False

        #store rule IDs which can subsume the new created rule
        SubsumeID=[]

        #check rules in a higher generalized clusters and find rules, which can subsume the newly created rule
        for cluster in range(clusterId+1, env.AttributeNumber+1):
            for rule in range(0, len(population[cluster])):
                if (population[cluster][rule].experience>config.theta_sub) and (population[cluster][rule].predictionError<=config.epsilon_0):
                    if Classifier_Operator.IsMoreGeneral(population[cluster][rule].encoding,encoding):
                        temp=[]
                        temp.append(cluster)
                        temp.append(rule)
                        SubsumeID.append(temp)

        #if none rule can subsume new created rule return false
        if len(SubsumeID)==0:
            return False

        #if the new created rule can be subsumed then return true
        if len(SubsumeID)==1:
            #update the numerosity
            population[SubsumeID[0][0]][SubsumeID[0][1]].numerosity+=1
            #empty garbage
            del SubsumeID[:]
            return True

        #if more than one rule can subsume the newly created rule, then randomly select one to apply the subsumption
        if len(SubsumeID)>1:
            SubId=random.randint(0,len(SubsumeID)-1)
            #update the numerosity
            population[SubsumeID[SubId][0]][SubsumeID[SubId][1]].numerosity+=1
            #empty garbage
            del SubsumeID[:]
            return True
         

    #attempt to inscert rules
    def __inscertOffspring(self,populationpool,action,encoding,General_Level,Classifier_Operator,Statistics,env, config,time):
        if not self.__SameRule(populationpool[action],encoding,General_Level,Classifier_Operator,Statistics):        
             if not self.__SubsumeRule(populationpool[action],encoding,General_Level,Classifier_Operator,env, config,Statistics):
                 classifier=Classifier_XCS(encoding,action,config.predictionIni,config.predictionErrorIni,config.fitnessIni,config.fitnessIni,time)
                 #introduce the new unique rule to the population pool
                 populationpool[action][General_Level].append(classifier)
                 #fitness sum
                 Statistics[1]+=classifier.fitness
                 #delete weight sum
                 Statistics[2]+=1
                 return True
             else:
                 return False
        else:
            return False


    #create two offspring classifiers
    def __Create_TwoOffsprings(self, populationpool,MatchSet,SelectedAction, time, Statistics, env, config, Classifier_Operator):
        
        Parent_1=self.__selectClassifierUsingTournamentSelection(populationpool[SelectedAction],MatchSet[SelectedAction],config)
        Parent_2=self.__selectClassifierUsingTournamentSelection(populationpool[SelectedAction],MatchSet[SelectedAction],config)
        #copy the encondings from their parents
        encoding_1=copy.deepcopy(populationpool[SelectedAction][Parent_1[0]][Parent_1[1]].encoding)
        encoding_2=copy.deepcopy(populationpool[SelectedAction][Parent_2[0]][Parent_2[1]].encoding)

        #implement crossover and mutation
        Classifier_Operator.twoPointsCrossover(encoding_1,encoding_2)
        Classifier_Operator.NicheMutation(encoding_1)
        Classifier_Operator.NicheMutation(encoding_2)
        action_1=Classifier_Operator.ActionMutation(SelectedAction)
        action_2=Classifier_Operator.ActionMutation(SelectedAction)

        #increase the sum of numerosity Statistics[0]
        Statistics[0]+=2

        #get generalization level of the new created rules
        General_Level_1=Classifier_Operator.Generalization_level(encoding_1)
        General_Level_2=Classifier_Operator.Generalization_level(encoding_2)


        if not self.__inscertOffspring(populationpool,action_1,encoding_1,General_Level_1,Classifier_Operator,Statistics,env,config,time):
            del encoding_1[:]


        if not self.__inscertOffspring(populationpool,action_2,encoding_2,General_Level_2,Classifier_Operator,Statistics,env,config,time):
            del encoding_2[:]
             

    #Rule discovery process
    def RuleDiscovery(self,populationpool,MatchSet,SelectedAction, time, Statistics, env, config, Classifier_Operator):
        #action set is empty then do not need rule discovery
        if len(MatchSet[SelectedAction])==0:
            return

        #sum of numerosity in action set
        setsum=0.0
        #sum of numerosity*timestamp in action set
        gaitsum=0.0

        #get all sums that are needed to do the discovery
        for rule in MatchSet[SelectedAction]:
            setsum+=populationpool[SelectedAction][rule[0]][rule[1]].numerosity
            gaitsum+=populationpool[SelectedAction][rule[0]][rule[1]].numerosity*populationpool[SelectedAction][rule[0]][rule[1]].timeStamp

        #do not do a GA is the average number of time-steps in the set since the last GA is less or equal than thetaGA
        if (time-(gaitsum/setsum))<config.theta_GA:
            return

        #update the timestamp equal to the last time that undergo the rulediscovery
        for rule in MatchSet[SelectedAction]:
            populationpool[SelectedAction][rule[0]][rule[1]].timeStamp= time

        #apply the rule discovery
        self.__Create_TwoOffsprings(populationpool,MatchSet,SelectedAction,time,Statistics,env,config,Classifier_Operator)


    #maintain the population pool's maximum population 
    def RemoveRules(self,populationpool,Stastics,max,config):
        #sum of numerosity Stastics[0]
        while Stastics[0]>max:
            #sum of delete weight
            choicep=random.random()*Stastics[2]
            sum=0
            find=False
            #remove rule id
            Rid=[]
            # loop the whole population find the rule for delete
            #a:action
            while find==False:
                for a in range(0, len(populationpool)):
                    #break the loop if find the rule for delete
                    if find:
                        break
                    #cluster
                    for c in range(0, len(populationpool[a])):
                        #break the loop if find the rule for delete
                        if find:
                            break
                        #rule
                        for r in range(0, len(populationpool[a][c])):
                            sum+=populationpool[a][c][r].deleteWeight
                            #once sum of delete weight is higher than the random select point
                            if sum>=choicep:
                                find=True
                                Rid.append(a)
                                Rid.append(c)
                                Rid.append(r)
                                break

            #reduce the selected rule's numerosity, if a rule's numerosity reach to zero, then remove it
            Stastics[0]-=1
            #directly remove rules, minus the removed fitness and deletionweight from the sum fitness and sum delete weight
            if populationpool[Rid[0]][Rid[1]][Rid[2]].numerosity==1:
                #sum of fitness
                Stastics[1]-=populationpool[Rid[0]][Rid[1]][Rid[2]].fitness
                #sum of deletion weight
                Stastics[2]-=populationpool[Rid[0]][Rid[1]][Rid[2]].deleteWeight
                populationpool[Rid[0]][Rid[1]].pop(Rid[2])
            else:
                #reduce the numerosity
                populationpool[Rid[0]][Rid[1]][Rid[2]].numerosity-=1
                #re-update the deletion weight
                average_fitness=populationpool[Rid[0]][Rid[1]][Rid[2]].fitness/populationpool[Rid[0]][Rid[1]][Rid[2]].numerosity
                meanf=Stastics[1]/Stastics[0]
                if average_fitness>=config.delta*meanf or populationpool[Rid[0]][Rid[1]][Rid[2]].experience< config.theta_del:
                    #sub the old delete weight
                    Stastics[2]-= populationpool[Rid[0]][Rid[1]][Rid[2]].deleteWeight
                    populationpool[Rid[0]][Rid[1]][Rid[2]].deleteWeight= populationpool[Rid[0]][Rid[1]][Rid[2]].actionSetSize*populationpool[Rid[0]][Rid[1]][Rid[2]].numerosity
                    #add the new delete weight
                    Stastics[2]+= populationpool[Rid[0]][Rid[1]][Rid[2]].deleteWeight
                else:
                    Stastics[2]-= populationpool[Rid[0]][Rid[1]][Rid[2]].deleteWeight
                    populationpool[Rid[0]][Rid[1]][Rid[2]].deleteWeight= populationpool[Rid[0]][Rid[1]][Rid[2]].actionSetSize*populationpool[Rid[0]][Rid[1]][Rid[2]].numerosity*meanf/average_fitness
                    Stastics[2]+= populationpool[Rid[0]][Rid[1]][Rid[2]].deleteWeight

    #output prediction
    def Prediction(self,PopulationPool,MatchSet,env, Stastistics):
        #calculate the prediction array 
        PredictionArray,SumFitnessArray=self.__GetPredictionArray(PopulationPool,MatchSet)
        #p: predicted action
        p=self.__bestActionWinner(PredictionArray,SumFitnessArray)
        #record number of unmatch cases
        if p==-1:
            Stastistics[3]+=1

        #record the training performance
        if p==env.Class:
            return 1
        else:
            return 0

     #save the performance
    def __save_performance(self,txt,name):
        f=open(name,'wb')
        f.write(txt.encode())
        f.close()

    #Convert a population to string
    def __ConvertToString(self,Population, Classifier_Operator):
        result=""
        for p in range(0,len(Population)):
            for c in range(0,len(Population[p])):
                for r in range(0,len(Population[p][c])):
                    temp=""
                    encod= Classifier_Operator.EncodingString(Population[p][c][r].encoding)
                    temp+=encod+" : "+str(Population[p][c][r].action)+" "
                    temp+="Numerosity: "+str(Population[p][c][r].numerosity)+" "
                    temp+="Fitness: "+str(round(Population[p][c][r].fitness,2))+" "
                    temp+="Prediction: "+str(round(Population[p][c][r].prediction,2))+" "
                    temp+="PredictionError: "+str(round(Population[p][c][r].predictionError,2))+" "
                    temp+="Experience: "+str(Population[p][c][r].experience)+" "
                    temp+="Accuracy: "+str(round(Population[p][c][r].accuracy,2))+" "
                    temp+="ActionSize: "+str(round(Population[p][c][r].actionSetSize,2))+" "
                    temp+="TimeStamp: "+str(round(Population[p][c][r].timeStamp,2))+" "
                    temp+="DeleteWeight: "+str(round(Population[p][c][r].deleteWeight,2))+" "+"\n"
                    result+=temp
        return result
       
    #calculate a time
    def __startTimer(self):
        local_time= time.localtime(time.time())
        format_time=time.strftime('DAY: %Y-%m-%d  Time: %H : %M : %S',local_time)
        #print format_time
        #print local_time
        Hour= local_time[3]
        Min= local_time[4]
        second= local_time[5]
        return str(Hour)+"_"+str(Min)+"_"+str(second)+"_"

    #generate a time
    def __GenerateName(self,environment):
        TimeUse=self.__startTimer()
        Name="Result/"
        Name+=TimeUse+str(environment.AttributeNumber)+ environment.problemName[environment.ProblemId]+".txt"
        return Name

    #save the performance
    def Save(self,population,classifier_operator,environment):
        name=self.__GenerateName(environment)
        result=self.__ConvertToString(population,classifier_operator)
        self.__save_performance(result,name)
    

    #Read an agent and output this agent into the format for rule compaction
    def Read_compact(self,address):
        population=[]
        informations=self.__Read_Information(address)
        for infor in informations:
            infor=infor.split('\n')[0].split("  : ")
            condition=infor[0].split(" ")
            parameter=infor[1].split(" ")
            action=int(parameter[0])
            numerosity=int(parameter[2])
            fitness=float(parameter[4])
            prediction=float(parameter[6])
            predictionError=float(parameter[8])
            experience=int( float(parameter[10]))
            accuracy=float(parameter[12])
            actionsize=float(parameter[14])
            rule=[]
            rule.append(condition)#0 encoding
            rule.append(action)#1 action
            rule.append(numerosity)#2 numerosity
            rule.append(accuracy)#3accuracy
            rule.append(fitness)#4fitness
            rule.append(predictionError)#5 prediction error
            rule.append(prediction)#6 prediction 
            rule.append(experience)#7 experience
            rule.append(actionsize)#8 action set size
            population.append(rule)

        #print(population)
        return population

    #get the paramaters id for the compaction
    #get the id of numerosity for rule compaction
    def GetNumerosityID(self):
        return 2

    #id of accuracy
    def GetAccuracyId(self):
        return 3

    #id of fitness
    def GetFitnessId(self):
        return 4

    #id of prediction error
    def GetPredictionErrorId(self):
        return 5

    #id of prediction
    def GetPredictionId(self):
        return 6

    #id of experience
    def GetExperienceId(self):
        return 7

    #id of actionsize
    def GetActionsizeId(self):
        return 8

    #calculate the prediction value
    def GetPredictValue(self,rule):
        #fitness * prediction
        return rule[6]*rule[4]

    def __Read_Information(self,address):
        read_information=open(address,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        #print (information)
        return information


    #judge whether this system has predictiom
    def Has_Prediction(self):
        return True