#in LCS, classifiers (rules) are the basic unit for exploring the problem and capturing the patterns.

class Classifier_XCS:
     def  __init__(self,Encodning,Action,Prediction,PredictionError,Accuracy,Fitness,TimeStamp):
         #encodings also term condition, recording the niches(instances) covered by this classifire
         self.encoding=Encodning

         #this rule advocated action (class inclassification)
         self.action=Action

         #this classifier's weight to be correct
         self.prediction=Prediction

         #the opposite of this classifier to be correct
         self.predictionError=PredictionError

         #the estimated prediction accuracy (function error)
         self.accuracy=Accuracy

         #show a rule's potential performance based on accuracy, also can be considered as a prediction weight
         self.fitness=Fitness

         #the duplicated number of this rule
         self.numerosity=1

         #the number of instances this rule 
         self.experience=0.0

         #the estimated niches of this rule
         self.actionSetSize=1

         #when this rule is created
         self.timeStamp=TimeStamp
         
         #weight for being delete
         self.deleteWeight=1.0