
import random
import os
class RealEnvironment:
    def __init__(self,problemId,attributeNumber,maxReward):
        self.ProblemId=problemId

        #support problem name
        self.problemName=["Mushroom","MushroomFull","ZOO","German"]

        # number of attributes
        self.AttributeNumber=0

        #the plausible actions of these problem
        self.PlausibleClassesId=[]
        self.PlausibleClassesName=[]

        #number of classes for these problems
        self.NumberClasses=0

        
        #store the input states
        self.__States=[]
        #store the input classes
        self.__Classes=[]
        self.instanceNumber=0
        self.Read()

        #reward for reinforcement learning
        self.Reward=maxReward
        #the current state
        self.State=[];

        #the current class
        self.Class=0;

        #count the corrent id for the state
        self.count=0


        #the plausible values of this problem
        self.PlausibleAtributeValueList=[]
        self.Initial_Plausible_Attribute_Values()

    def Read_Information(self,path):
        read_information=open(path,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        return information 

    #remove number 11  stalk-root attribute, as this attribute contains missing value 
    def Read_Mushroom(self):

        self.NumberClasses=2
        self.AttributeNumber=21 #(22-1)
        self.PlausibleClassesName=["poisonous","edible"]
        self.PlausibleClassesId=[0,1]
        raw_information=self.Read_Information("RData\\agaricus_lepiota.data")
        for raw in raw_information:
            o_raw=raw.split("\n")[0].split(",")
            #p:0 e:1
            if o_raw[0]=="p":
                self.__Classes.append(0)
            elif o_raw[0]=="e":
                self.__Classes.append(1)

            temp=[]
            for i in range(1,len(o_raw)):                
                if i!=11:
                    temp.append(o_raw[i])
            self.__States.append(temp)
        self.instanceNumber=len(self.__Classes)-1


    def Read_Mushroom_full(self):

        self.NumberClasses=2
        self.AttributeNumber=22 
        self.PlausibleClassesName=["poisonous","edible"]
        self.PlausibleClassesId=[0,1]
        raw_information=self.Read_Information("RData\\agaricus_lepiota.data")
        for raw in raw_information:
            o_raw=raw.split("\n")[0].split(",")
            #p:0 e:1
            if o_raw[0]=="p":
                self.__Classes.append(0)
            elif o_raw[0]=="e":
                self.__Classes.append(1)

            temp=[]
            for i in range(1,len(o_raw)):                
                if o_raw[i]!="?":
                    temp.append(o_raw[i])
                else:
                    temp.append("#")
                    
            self.__States.append(temp)

        self.instanceNumber=len(self.__Classes)-1



    def Read_Zoo(self):
        self.NumberClasses=7
        self.AttributeNumber=16
        self.PlausibleClassesName=["mammal","bird","Reptile","fish","Amphibian","insect","Invertebrates"]
        self.PlausibleClassesId=[0,1,2,3,4,5,6]
        raw_information=self.Read_Information("RData\\zoo.data")
        for raw in raw_information:
            o_raw=raw.split("\n")[0].split(",")
            #add states
            temp=[]
            for i in range(1,len(o_raw)-1):
                temp.append(o_raw[i])
            self.__States.append(temp)
            #add actions
            self.__Classes.append(int(o_raw[-1])-1)
        self.instanceNumber=len(self.__Classes)-1

    #mix numerical and interge
    def Read_German_Credit(self):
        self.NumberClasses=2
        self.AttributeNumber=20
        self.PlausibleClassesName=["good","bad"]
        self.PlausibleClassesId=[0,1]
        raw_information=self.Read_Information("RData\\german.data")
        for raw in raw_information:
            o_raw=raw.split("\n")[0].split(" ")
            #add states
            temp=[]
            for i in range(0,len(o_raw)-1):
                temp.append(o_raw[i])
            self.__States.append(temp)
            #add actions
            self.__Classes.append(int(o_raw[-1])-1)
        self.instanceNumber=len(self.__Classes)-1

    def Read(self):
        if self.ProblemId==0:
            self.Read_Mushroom()
        elif self.ProblemId==1:
            self.Read_Mushroom_full()
        elif self.ProblemId==2:
            self.Read_Zoo()
        elif self.ProblemId==3:
            self.Read_German_Credit()


    #iterative the whole dataset, once the iterative have been done return true otherwise return false
    def Next(self):
        #have
        if self.count>self.instanceNumber:
            self.count=0
            return True
        self.Class=self.__Classes[self.count]
        self.State=self.__States[self.count]
        self.count+=1
        return False

    #reset the value of the count
    def ReSetCount(self):
        self.count=0
       
    def RandomSample(self):
        id=random.randint(0,self.instanceNumber)
        self.Class=self.__Classes[id]
        self.State=self.__States[id]

     #return the reward of this environment
    def GetReward(self,P_Action):
        if self.Class==P_Action:
            return self.Reward
        return 0

    def Get_states(self):
        return self.__States


    #Initial the plausible values for each attribute
    def Initial_Plausible_Attribute_Values(self):
        result=[]
        for i in range(0,self.AttributeNumber):
            temp=[]
            result.append(temp)
        for sta in self.__States:
           for i in range(0,self.AttributeNumber):
               if not sta[i] in result[i]:
                   result[i].append(sta[i])          
            
        self.PlausibleAtributeValueList=result


#RealE=RealEnvironment(3,1,10)

