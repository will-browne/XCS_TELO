import imageio
import os


def ReadFiles():
        address="GIF/"
        files=os.listdir(address)
        
        for i in  range(0,len(files)):
            files[i]=address+files[i]
        print(files)
        return files

def compose_gif():
    paths=ReadFiles()
    gif_images=[]
    for path in paths:
        gif_images.append(imageio.imread(path))
    imageio.mimsave("test.gif",gif_images,fps=0.7)

compose_gif()