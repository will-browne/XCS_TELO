from PIL import Image
import os


def ReadFiles():
        address="maps/"
        files=os.listdir(address)
        
        for i in  range(0,len(files)):
            files[i]=address+files[i]
        print(files)
        return files

myFiles=ReadFiles()

def Convert(filelist):
    count=0
    for file in filelist:
        img = Image.open(file)
        name=str(count)+".gif"
        img.save(name)
        count+=1

Convert(myFiles)