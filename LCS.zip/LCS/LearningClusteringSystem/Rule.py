﻿

class Rule001:

    #create a single rule
    def Create_new_Single_Rule(self,condition,action,circleId):
        # 0: condition 
        # 1: action 
        # 2: numerosity 
        # 3: Positive_Prediction
        # 4: Negative prediction
        # 5: the inner circle ID of when this rule has been evolved


        rule=[]
        rule.append(condition) #0 condition
        rule.append(action) #1 action
        rule.append(1) #2 numerosity=duplicated time
        rule.append(0)#3 Positive-Prediction
        rule.append(0)#4 negative-Prediction
        rule.append(circleId)#5 inner circle ID



        return rule



    def Covert_Rule_String(self,rule):
        result=""
        condition=""
        for cod in rule[0]:
            condition+=str(cod)+" "
        result+=condition
        result+="---> " +str(rule[1])+" : "
        result+=" num "+str(rule[2])+" "
        result+=" P_Prediction "+str(rule[3])+" "
        result+=" N_Prediction "+str(rule[4])+" "
        result+=" Create_Circle "+str(rule[5])+" "
        result+="\n"
        return result

    def update_positive_prediction(self,rule,value):
        rule[3]+=value


    def update_negative_prediction(self,rule,value):
        rule[4]+=value


    def update_numerosity(self,rule,value):
        rule[2]+=value

    def Get_numerosity(self,rule):
        return rule[2]

    def Get_Condition(self,rule):
        return rule[0]

    def Get_Action(self,rule):
        return rule[1]

    def Get_Circle_Id(self,rule):
        return rule[5]


    def Get_positive_prediction(self,rule):
        return rule[3]


    def Get_negative_prediction(self,rule):
        return rule[4]


    def Discount_positive_prediction(self,rule,discount):
        rule[3]= int(rule[3]*discount)

    def Discount_negative_prediction(self,rule,discount):
        rule[4]= int(rule[4]*discount)