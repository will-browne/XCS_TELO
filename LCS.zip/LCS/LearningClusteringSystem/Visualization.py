﻿from ReadPopulation import ReadPopulation_Visualization
from ReadPopulation import ReadPopulation_UCS
from ReadPopulation import ReadPopulation_XCS


import numpy as np
import random
from mpl_toolkits.mplot3d import axes3d
import matplotlib.pyplot as plt
import os
import matplotlib.lines as mlines
import matplotlib as mpl
import copy
import os



#translate rules to patterns
class Value_knowledge:
    def __init__(self,address,action_list):


        Read_Pop=ReadPopulation_Visualization(address)
        #Read_Pop=ReadPopulation_UCS(address)
        #Read_Pop=ReadPopulation_XCS(address)

        self.action_list=action_list

        self.Raw_Population=Read_Pop.population

        self.clustered=self.Conver_to_Cluster()

        #for attribute importance
        #self.attribute_List=self.Calculate_Attribute_importance_distribution_Value()

        #for attribute value
        #self.attribute_List=self.Calculate_Attribute_importance_distribution_PureImportance()

        
        
    def Conver_to_Cluster(self):
        length=len(self.Raw_Population[0][0])
        cluster=[]
        for i in range(0,length+1):
            temp=[]
            cluster.append(temp)

        for rule in self.Raw_Population:
            level=self.General_Level(rule[0])
            cluster[level].append(rule)

        return cluster


    def General_Level(self,condition):
        count=0
        for cod in condition:
            if cod=='#':
                count+=1
        return count

    def Calculate_Attribute_importance_distribution_Value(self):
        
        #Initial the action based distribution list
        distribution_list=[]
        length=len(self.Raw_Population[0][0])
        #print len(self.negative_set)
        for i in range(0,len(self.clustered)):
            temp=[]
            for j in range(0,length):               
                temp.append(0)
            distribution_list.append(temp)

        #Action distributed list
        G_distribution_list=[]
        for i in range(0,len(self.action_list)):
            temp=copy.deepcopy(distribution_list)
            G_distribution_list.append(temp)

        G_count_list=copy.deepcopy(G_distribution_list)

        #Z_count_list=copy.deepcopy(G_distribution_list)

        #Z_distribution_list=copy.deepcopy(G_distribution_list)


        #print distribution_list
        for i in range(0,len(self.clustered)):
            if len(self.clustered[i])!=0:
                for rule in self.clustered[i]:
                    for cond_l in range(0,length):
                        if rule[0][cond_l]!='#':
                            if rule[1]==1:
                                G_distribution_list[rule[1]][i][cond_l]+=rule[0][cond_l]
                                G_count_list[rule[1]][i][cond_l]+=1

                            if rule[1]==0:
                                G_distribution_list[rule[1]][i][cond_l]+=rule[0][cond_l]-1
                                G_count_list[rule[1]][i][cond_l]+=1


                for d_l in range(0,length):
                    for action in self.action_list:
                        if G_count_list[action][i][d_l]!=0:
                            G_distribution_list[action][i][d_l]=1.0*G_distribution_list[action][i][d_l]/G_count_list[action][i][d_l]
                            #if G_distribution_list[action][i][d_l]==0:
                             #   G_distribution_list[action][i][d_l]=-1
        #print (G_distribution_list)
        #print len(distribution_list)



        return G_distribution_list


    def Calculate_Attribute_importance_distribution_PureImportance(self):
        
        #Initial the action based distribution list
        distribution_list=[]
        length=len(self.Raw_Population[0][0])
        #print len(self.negative_set)
        for i in range(0,len(self.clustered)):
            temp=[]
            for j in range(0,length):               
                temp.append(0)
            distribution_list.append(temp)

        #Action distributed list
        G_distribution_list=[]
        for i in range(0,len(self.action_list)):
            temp=copy.deepcopy(distribution_list)
            G_distribution_list.append(temp)

        G_count_list=copy.deepcopy(G_distribution_list)

        #Z_count_list=copy.deepcopy(G_distribution_list)

        #Z_distribution_list=copy.deepcopy(G_distribution_list)


        #print distribution_list
        for i in range(0,len(self.clustered)):
            if len(self.clustered[i])!=0:
                for rule in self.clustered[i]:
                    for cond_l in range(0,length):
                        if rule[0][cond_l]!='#':
                            G_distribution_list[rule[1]][i][cond_l]+=1
                            G_count_list[rule[1]][i][cond_l]+=1
                        else:
                            G_count_list[rule[1]][i][cond_l]+=1


                for d_l in range(0,length):
                    for action in self.action_list:
                        if G_count_list[action][i][d_l]!=0:
                            G_distribution_list[action][i][d_l]=1.0*G_distribution_list[action][i][d_l]/G_count_list[action][i][d_l]
                            #if G_distribution_list[action][i][d_l]==0:
                            #    G_distribution_list[action][i][d_l]=-1
        print (G_distribution_list)
        #print len(distribution_list)



        return G_distribution_list


    def Calculate_Attribute_importance_distribution_PureImportance_NOACTION(self):
        
        #Initial the action based distribution list
        distribution_list=[]
        length=len(self.Raw_Population[0][0])
        #print len(self.negative_set)
        for i in range(0,len(self.clustered)):
            temp=[]
            for j in range(0,length):               
                temp.append(0)
            distribution_list.append(temp)

        #Action distributed list

        
        G_distribution_list=copy.deepcopy(distribution_list)


        G_count_list=copy.deepcopy(G_distribution_list)

        #Z_count_list=copy.deepcopy(G_distribution_list)

        #Z_distribution_list=copy.deepcopy(G_distribution_list)


        #print distribution_list
        for i in range(0,len(self.clustered)):
            if len(self.clustered[i])!=0:
                for rule in self.clustered[i]:
                    for cond_l in range(0,length):
                        if rule[0][cond_l]!='#':
                            G_distribution_list[i][cond_l]+=1
                            G_count_list[i][cond_l]+=1
                        else:
                            G_count_list[i][cond_l]+=1


                for d_l in range(0,length):
                        if G_count_list[i][d_l]!=0:
                            G_distribution_list[i][d_l]=1.0*G_distribution_list[i][d_l]/G_count_list[i][d_l]
                            #if G_distribution_list[action][i][d_l]==0:
                            #    G_distribution_list[action][i][d_l]=-1
        print (G_distribution_list)
        #print len(distribution_list)



        return G_distribution_list

class Value_Knowledge_Running:
    def __init__(self,path):
        self.png_path=path
        self.name=1
        print ("Start Value Knowledge Record")

    def Generate_Knowledge(self, population_0, population_1,length):
        #Initial the action based distribution list
        Rule_Number=[]
        for i in range(0,length+1):
            Rule_Number.append(0)


        distribution_list=[]
        #print len(self.negative_set)
        for i in range(0,length+1):
            temp=[]
            for j in range(0,length):               
                temp.append(0)
            distribution_list.append(temp)

        #Action distributed list

        
        G_distribution_list=copy.deepcopy(distribution_list)


        G_count_list=copy.deepcopy(G_distribution_list)

        for i in range(0,len(population_0.population)):
            if len(population_0.population[i].cluster)+len(population_1.population[i].cluster)!=0:
                Rule_Number[i]=(len(population_0.population[i].cluster)+len(population_1.population[i].cluster))*2
                for rule in population_0.population[i].cluster:
                    for cond_l in range(0,length):
                        if rule[0][cond_l]!='#':
                            G_distribution_list[i][cond_l]+=1
                            G_count_list[i][cond_l]+=1
                        else:
                            G_count_list[i][cond_l]+=1

                for rule in population_1.population[i].cluster:
                    for cond_l in range(0,length):
                        if rule[0][cond_l]!='#':
                            G_distribution_list[i][cond_l]+=1
                            G_count_list[i][cond_l]+=1
                        else:
                            G_count_list[i][cond_l]+=1

                for d_l in range(0,length):
                        if G_count_list[i][d_l]!=0:
                            G_distribution_list[i][d_l]=1.0*G_distribution_list[i][d_l]/G_count_list[i][d_l]
        print (G_distribution_list)
        print(Rule_Number)
        return G_distribution_list,Rule_Number


    def Drew_NOACT(self,distribution_list,R_number,accuracy,iteration):
        fig=plt.figure(figsize=(10, 10), dpi=150)
        ax1=fig.add_subplot(111,projection='3d')
        z_first=np.asarray(distribution_list)
        z=z_first.T


        
        xlabels_t=[]       
        for i in range(0,len(z)):
            xlabels_t.append(str(i))
        xlabels=np.array(xlabels_t)
        xpos=np.arange(xlabels.shape[0])

        ylabels_t=[]       
        for i in range(0,len(z[0])):
            ylabels_t.append(str(i) +'('+ str(R_number[i])+')')
        ylabels=np.array(ylabels_t)
        ypos=np.arange(ylabels.shape[0])



        xposM, yposM=np.meshgrid(xpos,ypos,copy=False)

        dx=0.3
        dy=0.1

        ax1.w_xaxis.set_ticks(xpos + dx/2.)
        ax1.w_xaxis.set_ticklabels(xlabels)

        ax1.w_yaxis.set_ticks(ypos + dy/3.)
        ax1.w_yaxis.set_ticklabels(ylabels)

        color_list=['#EE7700','DarkGreen', 'Blue', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan','tab:blue', 'tab:orange', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan']

        line_list=['--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':']
        #for act in range(6,7):
        
        z_first=np.asarray( distribution_list)
        z=z_first.T

        y=[]

        for i in range(0,len(z[0])):
            y.append(i)



        for i in range(0,len(z)):
            x=[i]*len(z[i])
            if len(z)>20:


                ax1.plot(x, y, z[i], line_list[act],color=color_list[act],lw=3,alpha=3)

                ax1.legend()
                for j in range(0,len(z[i])):
                    if z[i][j] !=0 and i%4==0:

                        ax1.text(i, j, z[i][j]+0.1, str(round(z[i][j],2)), color=color_list[0])  
            else:
                ax1.plot(x, y, z[i], line_list[0], color=color_list[0],lw=2)
                ax1.legend()
                for j in range(0,len(z[i])):
                    if z[i][j]!=0:
                        ax1.text(i, j, z[i][j]+0.01, str(round(z[i][j],2)), color=color_list[0])
 

            
                       


        ax1.set_xlabel('X ', fontsize=20)
        ax1.set_title('Accuracy: '+ str(accuracy) +"  Iterations: "+str(iteration), fontsize=20)
        ax1.set_ylabel('Y', fontsize=20)
        ax1.set_zlabel("Z", fontsize=20)


        for angle in range(115, 117,1):
           ax1.view_init(10, angle)
           plt.draw()
           png_complete_name = self.png_path + str(self.name) + ".png"
            # fig.savefig(png_complete_name, dpi=(400))
            #fig.savefig(png_complete_name,bbox_inches='tight')
           fig.savefig(png_complete_name)
           plt.pause(.001)
        self.name+=1
        plt.show()

class Visualize_value_pattern:
    def __init__(self,address,action_list,path,MapID):
        self.action_list=action_list
        V_K=Value_knowledge(address,action_list)
        self.png_path=path
        if MapID==0:
            self.distribution_list=V_K.Calculate_Attribute_importance_distribution_Value()
            self.Drew()
        elif MapID==1:
            self.distribution_list=V_K.Calculate_Attribute_importance_distribution_PureImportance()
            self.Drew()
        elif MapID==2:
             self.distribution_list=V_K.Calculate_Attribute_importance_distribution_PureImportance_NOACTION() 
             self.Drew_NOACT()   

       
        #self.Drew_Real()
    def Rainbown_color(self,length):
        R=0xff
        G_begin=0x66
        B_begin=0x66
        step=G_begin//length
        color='#'
        colors=[]
        for i in range(0,length):
            #color=color+str(hex(R))+str(hex(B_begin+step*i))+str(hex(G_begin-step*i))
            color=color+self.translate_sixteen_string(R)+self.translate_sixteen_string(B_begin+step*i)+self.translate_sixteen_string(B_begin-step*i)
            colors.append(color)
            color='#'
        #for co in colors:
        #    print co
        return colors


    def translate_sixteen_string(self,value):
        if abs(value)<0x10:
            #print value, '           ', 0x10
            result='0'
            result=result+str(hex(value)).split('x')[-1]
        else:
         result=str(hex(value)).split('x')[-1]
        return result   


    def Detect_Inforative_levels(self,list):
         result=[]
         for i in range(0,len(list)):
             for j in list[i]:
                 if j!=0:
                    result.append(i)
                    break
         print (result)
         return result


    def Drew(self):
        fig=plt.figure(figsize=(10, 10), dpi=150)
        ax1=fig.add_subplot(111,projection='3d')
        z_first=np.asarray( self.distribution_list[0])
        z=z_first.T


        
        xlabels_t=[]       
        for i in range(0,len(z)):
            xlabels_t.append(str(i))
        xlabels=np.array(xlabels_t)
        xpos=np.arange(xlabels.shape[0])

        ylabels_t=[]       
        for i in range(0,len(z[0])):
            ylabels_t.append(str(i))
        ylabels=np.array(ylabels_t)
        ypos=np.arange(ylabels.shape[0])



        xposM, yposM=np.meshgrid(xpos,ypos,copy=False)

        dx=0.3
        dy=0.1

        ax1.w_xaxis.set_ticks(xpos + dx/2.)
        ax1.w_xaxis.set_ticklabels(xlabels)

        ax1.w_yaxis.set_ticks(ypos + dy/3.)
        ax1.w_yaxis.set_ticklabels(ylabels)

        color_list=['#EE7700','DarkGreen', 'Blue', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan','tab:blue', 'tab:orange', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan']

        line_list=['--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':']
        #for act in range(6,7):
        for act in range(0,len(self.action_list)):
            important_list=self.Detect_Inforative_levels(self.distribution_list[act])
            z_first=np.asarray( self.distribution_list[act])
            z=z_first.T

            y=[]

            for i in range(0,len(z[0])):
                y.append(i)



            for i in range(0,len(z)):
                x=[i]*len(z[i])
                if len(z)>20:


                    ax1.plot(x, y, z[i], line_list[act],color=color_list[act],lw=3,alpha=3)

                    ax1.legend()
                    for j in range(0,len(z[i])):
                        if z[i][j] !=0 and i%4==0:

                            ax1.text(i, j, z[i][j]+0.1, str(round(z[i][j],2)), color=color_list[act])  
                else:
                    ax1.plot(x, y, z[i], line_list[act], color=color_list[act],lw=2)
                    ax1.legend()
                    for j in range(0,len(z[i])):
                        if z[i][j]!=0:
                            ax1.text(i, j, z[i][j]+0.01, str(round(z[i][j],2)), color=color_list[act])
   
        



            
            #y=[]
            #count=0
            #for i in range(0,len(z_first[0])):
            #    y.append(i)
         
            #for level in important_list:
            #    x=[level]*len(z_first[level])
            #    n_z=z_first[level]
            
            #    ax1.plot( y, x,n_z, '--', color=color_list[count],lw=1,alpha=3)

                    
            #    ax1.scatter(y, x,n_z,color=color_list[count]) 
            #    count+=1
            #    if count>len(color_list):
            #        count=0

            
                       


        ax1.set_xlabel('X ', fontsize=20)
        #ax1.set_title('6-BIT MUX', fontsize=30)
        ax1.set_ylabel('Y', fontsize=20)
        ax1.set_zlabel("Z", fontsize=20)


        #ax1.set_title('RCR 11-Bits MUX', fontsize=20)
        #ax1.set_title('RCR 10-Bits Carry', fontsize=20)
        #ax1.set_title('RCR 11-Bits Majority-On', fontsize=20)


        #ax1.set_title('QRC 11-Bits MUX', fontsize=20)
        #ax1.set_title('QRC 10-Bits Carry', fontsize=20)
        #ax1.set_title('QRC 11-Bits Majority-On', fontsize=20)


        #ax1.set_title('FU1 11-Bits MUX', fontsize=20)
        #ax1.set_title('FU1 10-Bits Carry', fontsize=20)
        #ax1.set_title('FU1 11-Bits Majority-On', fontsize=20)


        #ax1.set_title('AFIM 20-Bits MUX', fontsize=20)
        #ax1.set_title('AFVM 20-Bits MUX', fontsize=20)
        #ax1.set_title('AFIM 37-Bits MUX', fontsize=20)
        #ax1.set_title('AFVM 37-Bits MUX', fontsize=20)
        #ax1.set_title('AFIM 70-Bits MUX', fontsize=20)
        #ax1.set_title('AFVM 70-Bits MUX', fontsize=20)


        #ax1.set_title('AFIM 10-Bits Carry', fontsize=20)
        #ax1.set_title('AFVM 10-Bits Carry', fontsize=20)
        #ax1.set_title('AFIM 12-Bits Carry', fontsize=20)
        #ax1.set_title('AFVM 12-Bits Carry', fontsize=20)
        #ax1.set_title('AFIM 14-Bits Carry', fontsize=20)
        #ax1.set_title('AFVM 14-Bits Carry', fontsize=20)


        #ax1.set_title('AFIM 7-Bits Majority-On', fontsize=20)
        #ax1.set_title('AFVM 7-Bits Majority-On', fontsize=20)
        #ax1.set_title('AFIM 11-Bits Majority-On', fontsize=20)
        #ax1.set_title('AFVM 11-Bits Majority-On', fontsize=20)
        #ax1.set_title('AFIM 13-Bits Majority-On', fontsize=20)
        #ax1.set_title('AFVM 13-Bits Majority-On', fontsize=20)


        #ax1.set_title('AFIM 8-Bits Majority-On', fontsize=20)
        #ax1.set_title('AFVM 8-Bits Majority-On', fontsize=20)
        #ax1.set_title('AFIM 12-Bits Majority-On', fontsize=20)
        #ax1.set_title('AFVM 12-Bits Majority-On', fontsize=20)
        #ax1.set_title('AFIM 14-Bits Majority-On', fontsize=20)
        #ax1.set_title('AFVM 14-Bits Majority-On', fontsize=20)
        """
        for angle in range(1, 370,5):
            ax1.view_init(30, angle)
            plt.draw()
            png_complete_name = self.png_path + str(angle) + ".png"
            #fig.savefig(png_complete_name, dpi=(400))
            #fig.savefig(png_complete_name,bbox_inches='tight')
            #print(png_complete_name)
            fig.savefig(png_complete_name)
            plt.pause(.001)
        """

        #for angle in range(1, 370,5):
        for angle in range(0, 421,60):
            #115, 117,1
            ax1.view_init(30, angle)
            plt.draw()
            png_complete_name = self.png_path + str(angle) + ".jpg"
            #fig.savefig(png_complete_name, dpi=(400))
            fig.savefig(png_complete_name,bbox_inches='tight')
            #fig.savefig(png_complete_name)
            plt.pause(.001)
        plt.show()

    def Drew_Single(self):
        fig=plt.figure(figsize=(10, 10), dpi=150)
        ax1=fig.add_subplot(111,projection='3d')
        z_first=np.asarray( self.distribution_list[0])
        z=z_first.T


        
        xlabels_t=[]       
        for i in range(0,len(z)):
            xlabels_t.append(str(i))
        xlabels=np.array(xlabels_t)
        xpos=np.arange(xlabels.shape[0])

        ylabels_t=[]       
        for i in range(0,len(z[0])):
            ylabels_t.append(str(i))
        ylabels=np.array(ylabels_t)
        ypos=np.arange(ylabels.shape[0])



        xposM, yposM=np.meshgrid(xpos,ypos,copy=False)

        dx=0.3
        dy=0.1

        ax1.w_xaxis.set_ticks(xpos + dx/2.)
        ax1.w_xaxis.set_ticklabels(xlabels)

        ax1.w_yaxis.set_ticks(ypos + dy/3.)
        ax1.w_yaxis.set_ticklabels(ylabels)

        color_list=['#EE7700','DarkGreen', 'Blue', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan','tab:blue', 'tab:orange', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan']

        line_list=['--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':']
        #for act in range(6,7):
        for act in range(0,len(self.action_list)):
            important_list=self.Detect_Inforative_levels(self.distribution_list[act])
            z_first=np.asarray( self.distribution_list[act])
            z=z_first.T

            y=[]

            for i in range(0,len(z[0])):
                y.append(i)



            for i in range(0,len(z)):
                x=[i]*len(z[i])
                if len(z)>20:


                    ax1.plot(x, y, z[i], line_list[act],color=color_list[act],lw=3,alpha=3)

                    ax1.legend()
                    for j in range(0,len(z[i])):
                        if z[i][j] !=0 and i%4==0:

                            ax1.text(i, j, z[i][j]+0.1, str(round(z[i][j],2)), color=color_list[act])  
                else:
                    ax1.plot(x, y, z[i], line_list[act], color=color_list[act],lw=2)
                    ax1.legend()
                    for j in range(0,len(z[i])):
                        if z[i][j]!=0:
                            ax1.text(i, j, z[i][j]+0.01, str(round(z[i][j],2)), color=color_list[act])
   
        



            
            #y=[]
            #count=0
            #for i in range(0,len(z_first[0])):
            #    y.append(i)
         
            #for level in important_list:
            #    x=[level]*len(z_first[level])
            #    n_z=z_first[level]
            
            #    ax1.plot( y, x,n_z, '--', color=color_list[count],lw=1,alpha=3)

                    
            #    ax1.scatter(y, x,n_z,color=color_list[count]) 
            #    count+=1
            #    if count>len(color_list):
            #        count=0

            
                       


        ax1.set_xlabel('X ', fontsize=20)
        #ax1.set_title('6-BIT MUX', fontsize=30)
        ax1.set_ylabel('Y', fontsize=20)
        ax1.set_zlabel("Z", fontsize=20)

        """
        for angle in range(1, 370,5):
            ax1.view_init(30, angle)
            plt.draw()
            png_complete_name = self.png_path + str(angle) + ".png"
            #fig.savefig(png_complete_name, dpi=(400))
            #fig.savefig(png_complete_name,bbox_inches='tight')
            #print(png_complete_name)
            fig.savefig(png_complete_name)
            plt.pause(.001)
        """

        for angle in range(116, 117,1):
            ax1.view_init(30, angle)
            plt.draw()
            png_complete_name = self.png_path + str(name) + ".png"
            # fig.savefig(png_complete_name, dpi=(400))
            #fig.savefig(png_complete_name,bbox_inches='tight')
            fig.savefig(png_complete_name)
            plt.pause(.001)
        self.name+=1

    def Drew_NOACT(self):
        fig=plt.figure(figsize=(10, 10), dpi=150)
        ax1=fig.add_subplot(111,projection='3d')
        z_first=np.asarray( self.distribution_list)
        z=z_first.T


        
        xlabels_t=[]       
        for i in range(0,len(z)):
            xlabels_t.append(str(i))
        xlabels=np.array(xlabels_t)
        xpos=np.arange(xlabels.shape[0])

        ylabels_t=[]       
        for i in range(0,len(z[0])):
            ylabels_t.append(str(i))
        ylabels=np.array(ylabels_t)
        ypos=np.arange(ylabels.shape[0])



        xposM, yposM=np.meshgrid(xpos,ypos,copy=False)

        dx=0.3
        dy=0.1

        ax1.w_xaxis.set_ticks(xpos + dx/2.)
        ax1.w_xaxis.set_ticklabels(xlabels)

        ax1.w_yaxis.set_ticks(ypos + dy/3.)
        ax1.w_yaxis.set_ticklabels(ylabels)

        color_list=['#EE7700','DarkGreen', 'Blue', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan','tab:blue', 'tab:orange', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan']

        line_list=['--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':']
        #for act in range(6,7):
        
        important_list=self.Detect_Inforative_levels(self.distribution_list)
        z_first=np.asarray( self.distribution_list)
        z=z_first.T

        y=[]

        for i in range(0,len(z[0])):
            y.append(i)



        for i in range(0,len(z)):
            x=[i]*len(z[i])
            if len(z)>20:


                ax1.plot(x, y, z[i], line_list[act],color=color_list[act],lw=3,alpha=3)

                ax1.legend()
                for j in range(0,len(z[i])):
                    if z[i][j] !=0 and i%4==0:

                        ax1.text(i, j, z[i][j]+0.1, str(round(z[i][j],2)), color=color_list[0])  
            else:
                ax1.plot(x, y, z[i], line_list[0], color=color_list[0],lw=2)
                ax1.legend()
                for j in range(0,len(z[i])):
                    if z[i][j]!=0:
                        ax1.text(i, j, z[i][j]+0.01, str(round(z[i][j],2)), color=color_list[0])
 

            
                       


        ax1.set_xlabel('X ', fontsize=20)
        ax1.set_ylabel('Y', fontsize=20)
        ax1.set_zlabel("Z", fontsize=20)


        #ax1.set_title('ASCS 11-Bits MUX', fontsize=20)
        #ax1.set_title('ASCS 12-Bits Carry', fontsize=20)
        #ax1.set_title('ASCS 13-Bits Majority-On', fontsize=20)


        #ax1.set_title('XCS 11-Bits MUX', fontsize=20)
        #ax1.set_title('XCS 12-Bits Carry', fontsize=20)
        #ax1.set_title('XCS 13-Bits Majority-On', fontsize=20)


        #ax1.set_title('UCS 11-Bits MUX', fontsize=20)
        #ax1.set_title('UCS 12-Bits Carry', fontsize=20)
        #ax1.set_title('UCS 13-Bits Majority-On', fontsize=20)


        #ax1.set_title('RCR 11-Bits MUX', fontsize=20)
        #ax1.set_title('RCR 10-Bits Carry', fontsize=20)
        #ax1.set_title('RCR 11-Bits Majority-On', fontsize=20)


        #ax1.set_title('QRC 11-Bits MUX', fontsize=20)
        #ax1.set_title('QRC 10-Bits Carry', fontsize=20)
        #ax1.set_title('QRC 11-Bits Majority-On', fontsize=20)


        #ax1.set_title('FU1 11-Bits MUX', fontsize=20)
        #ax1.set_title('FU1 10-Bits Carry', fontsize=20)
        #ax1.set_title('FU1 11-Bits Majority-On', fontsize=20)

        #ax1.set_title('Hidden 14+6-Bits Carry', fontsize=20)
        #ax1.set_title('Hidden 3+14+3-Bits Carry', fontsize=20)
        #ax1.set_title('Hidden 6+14-Bits Carry', fontsize=20)

        #ax1.set_title('Hidden 13+7-Bits Majority-On', fontsize=20)
        #ax1.set_title('Hidden 7+13-Bits Majority-On', fontsize=20)
        #ax1.set_title('Hidden 4+13+3-Bits Majority-On', fontsize=20)
        

        #ax1.set_title('Hidden 14+6-Bits Multiplexer', fontsize=20)
        #ax1.set_title('Hidden 6+14-Bits Multiplexer', fontsize=20)
        #ax1.set_title('Hidden 2+14+4-Bits Multiplexer', fontsize=20)


        #ax1.set_title('Natural Solution', fontsize=20)
        #ax1.set_title('N-ORC', fontsize=20)
        #ax1.set_title('Butz\'s solution', fontsize=20)

        ax1.set_title('FIM 10-Bits Carry', fontsize=20)

        #for angle in range(115, 117,1):
        for angle in range(293, 295,1):
            ax1.view_init(30, angle)
            plt.draw()
            png_complete_name = self.png_path + str(angle) + ".png"
            # fig.savefig(png_complete_name, dpi=(400))
            #fig.savefig(png_complete_name,bbox_inches='tight')
            fig.savefig(png_complete_name)
            plt.pause(.001)

        plt.show()




#70-BITS MUX
#Address="V_Pop\\MUX\\MUX702019_7_22_19_32_7.txt"
#37-BITS MUX
#Address="V_Pop\\MUX\\MUX37RCR2019_7_13_6_32_10.txt"
#20-BITS MUX
#Address="V_Pop\\MUX\\MUX20RCR2019_7_12_15_2_49.txt"
#11-BITS MUX
#Address="V_Pop\\MUX11RCR2019_7_11_5_58_34.txt"
#6-BITS MUX
#Address="V_Pop\\MUX6RCR2019_7_10_17_27_20.txt"
#10-BITS CARRY
#Address="V_Pop\\RCR\\Carry10RCR32019_7_13_3_15_47.txt"
#11-BITS Majority-On
#Address="V_Pop\\RCR\\Majority11RCR32019_8_1_21_28_10.txt"
#8-BITS Majority-On
#Address="V_Pop\\MOE\\Majority8RCR2019_7_12_4_40_45.txt"
#7-BITS Majority-On
Address="V_Pop\\MOO\\Majority7RCR2019_7_11_6_21_52.txt"
Path="DResult\\"
action_list=[0,1]
vvp=Visualize_value_pattern(Address,action_list,Path,1)
