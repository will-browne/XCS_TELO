import os

#Read a compacted population (only consist condition and action)
class Read_Compacted_Solution:

    def __init__(self,address,IsLinux):
        self.IsLinux=IsLinux
        self.address=address
        self.population=[]
        self.Read()
        #self.Print_Rule()
        #self.Re_State()
        self.length= len(self.population)

    def Read_Information(self,address):
        if self.IsLinux==False:
            name='Test_Population/'+address
        else:
            name=os.getcwd()+'/LCUS/Test_Population/'+address
        read_information=open(name,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        #print (information)
        return information

    def Read(self):
        informations=self.Read_Information(self.address)
        for raw in informations:

            extracted= raw.split('\n')[0].split(' :')
            action=int(extracted[1].split(' ')[-1])
            condition=extracted[0].split(' ')[0:-1]
            for i in range(0,len(condition)):
                if condition[i]!='#':
                    if not '.' in condition[i]:
                        condition[i]=int(condition[i])
                    else:
                        condition[i]=float(condition[i])
            rule=self.create_rule(condition,action)
            self.population.append(rule)
         


    def create_rule(self,condition,action):
        rule=[]
        rule.append(condition)
        rule.append(action)
        #whether detect
        return rule



    def Print_Rule(self):
        for rule in self.population:
            print(rule)

class Compare_solution:    

    def __init__(self,address,Is_Linus):
        self.target=Read_Compacted_Solution(address,Is_Linus)
        self.count=0
        print("Record Pattern Rate")


    #compare two condition
    def Is_Same_Condition(self,condition_1,condition_2):
        for i in range(0,len(condition_1)):
            if condition_1[i] != condition_2[i]:
                return False
        return True


    def compare_rule(self,condition,action):
        for rule in self.target.population:
            if rule[1]==action:
                if self.Is_Same_Condition(rule[0],condition):
                    self.count+=1


    def ReSet(self):
        self.count=0


    def Calculate_Rate(self):
        return 1.0*self.count/self.target.length



#address="MUX11RCR2019_7_11_5_58_34.txt"
#RC=Read_Compacted_Solution(address,False)