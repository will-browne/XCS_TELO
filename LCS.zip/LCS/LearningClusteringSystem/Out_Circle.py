﻿class Out_Circle_Operations:

    def __init__(self,Representation_Operator, Rule_Operator):
        print ("Out Circle Operations Loading Completed")

        self.Rep_Oper=Representation_Operator


        self.Rule_Oper=Rule_Operator

        self.experience_discount=0.8

    ##########################################################################################################################
    ####################                            The test for remove overly genreal rule                        ###########
    ####################                                     Operators                                             ###########
    ##########################################################################################################################


    #state: state of instance
    #population: a population
    def TrainingTest_Update_Parameters(self,state,population,reward):

        for i in range(0,len(population.population)):
            for j in range(0,len(population.population[i].cluster)):
                rule=population.population[i].cluster[j]
                condition=self.Rule_Oper.Get_Condition(rule)
                if self.Rep_Oper.isConditionMatched(state,condition):
                    #update the matched rule
                    if reward>1:
                        self.Rule_Oper.update_positive_prediction(rule,1)
                    else:
                        self.Rule_Oper.update_negative_prediction(rule,1)


    #remove the overly-general rule in a single cluster
    def TrainingTest_Remove_Overly_General_cluster(self, cluster):
        delete_list=[]
        for i in range(0,len(cluster.cluster)):
            rule=cluster.cluster[i]
            positive_value=self.Rule_Oper.Get_positive_prediction(rule)
            negative_value=self.Rule_Oper.Get_negative_prediction(rule)
            if positive_value*negative_value!=0:
                delete_list.append(i)

        count=0
        for id in delete_list:
            rule=cluster.cluster[id-count]
            numerosity=self.Rule_Oper.Get_numerosity(rule)
            cluster.cluster.pop(id-count)
            #update the number of absumption removed rules
            cluster.Out_numAbsumptionRemoved[-1]+=numerosity
            cluster.totalNumAbsumptionRemoved+=numerosity
            count+=1
        return count

    #remove the overly-general rules after test of training-set
    def TrainingTest_Implement_Remove(self,population):
        for cluster in population.population:
            delet_number=self.TrainingTest_Remove_Overly_General_cluster(cluster)
            population.numRules-=delet_number
            


    #initial the list for store the vote value for different action
    def Initial_prediction_list(self,action_size):
        result=[]
        for i in range(0,action_size):
            result.append(0.0)
        return result

    #update training parameters and the prediction list
    def TrainingTest_Update_Parameters_and_predictionlist(self,state,population,reward,prediction_list):
        #count the number of matched rule
        count=0
        for i in range(0,len(population.population)):
            for j in range(0,len(population.population[i].cluster)):
                rule=population.population[i].cluster[j]
                condition=self.Rule_Oper.Get_Condition(rule)
                if self.Rep_Oper.isConditionMatched(state,condition):
                    count+=1
                    #update the matched rule
                    if reward>1:
                        self.Rule_Oper.update_positive_prediction(rule,1)
                    else:
                        self.Rule_Oper.update_negative_prediction(rule,1)

                    
                    positive_experience=self.Rule_Oper.Get_positive_prediction(rule)
                    negative_experience=self.Rule_Oper.Get_negative_prediction(rule)

                    prediction_list[population.support_act]+=(positive_experience-negative_experience)
                    #prediction_list[population.support_act]-=negative_experience

        return count

    #out put the predicted action
    def output_action(self,prediction_list):
        if prediction_list==None:
            return None

        max=0
        maxid=0
        for action in range(1,len(prediction_list)):
            if prediction_list[action]>max:
                max=prediction_list[action]
                maxid=action

        return maxid

    ##########################################################################################################################
    ####################                           Set the training properties after bigCirc                       ###########
    ####################                                     Operators                                             ###########
    ##########################################################################################################################

    def Set_Properties(self,population,big_circle):
        for id in range(1,len(population.population)):
            cluster=population.population[id]
            if id<len(population.population)-1:
                pre_cluster=population.population[id-1]
            #if len(cluster.cluster)-big_circle-1>0:

            #if len(cluster.cluster)==0:
            #     cluster.Active=False


            if len(cluster.cluster)>0 or len(pre_cluster.cluster)>0:
                cluster.totalNumAbsumptionRemoved=0
                cluster.totalNumSumptionRemoved=0
                cluster.Active=True
        #update the new circle for inner circle
        self.Discount_experience(population)
        population.Activate_Cluster()



    # Discount the experience for make subsumption convenient
    def Discount_experience(self,population):
        for cluster in population.population:
            for rule in cluster.cluster:
                self.Rule_Oper.Discount_positive_prediction(rule,self.experience_discount)
                self.Rule_Oper.Discount_negative_prediction(rule,self.experience_discount)


    ##########################################################################################################################
    ####################                          bigCirc  Subsumption                                             ###########
    ####################                                     Operators                                             ###########
    ##########################################################################################################################

    #Judge whether this rule could be subsumed 
    def Is_Rule_Subsumable(self,cluster,candidate,candidate_experience):
        for rule in cluster.cluster:
            experience=self.Rule_Oper.Get_positive_prediction(rule)+self.Rule_Oper.Get_negative_prediction(rule)
            if experience>candidate_experience:
                condition=self.Rule_Oper.Get_Condition(rule)
                if self.Rep_Oper.Is_Condition_Subsumeable(condition,candidate):
                    return True
        return False

    def Out_Subsume(self,  population, candidate_rule, candidate_general):

        candidate=self.Rule_Oper.Get_Condition(candidate_rule)
        experience=self.Rule_Oper.Get_positive_prediction(candidate_rule)+self.Rule_Oper.Get_negative_prediction(candidate_rule)
        #can be subsumed
        for ID in range(candidate_general+1,len(population.population)):
             if self.Is_Rule_Subsumable(population.population[ID],candidate,experience):
                 return True

        #cannot be subsumed
        return  False


    #run the subsumption
    def Out_Implement_Subsumption(self,population):
        for general in range(0,len(population.population)):
            #initial the delete list
            delete_list=[]

            #initial the count
            count=0

            #check all the rules in a cluster
            for id in range(0,len(population.population[general].cluster)):
                candidate_rule=population.population[general].cluster[id]
                if self.Out_Subsume(population,candidate_rule,general):
                    delete_list.append(id)

            
            for d_id in delete_list:
                rule=population.population[general].cluster[d_id-count]
                numerosity=self.Rule_Oper.Get_numerosity(rule)
                #update subsump removed rules
                population.population[general].Out_numSumptionRemoved[-1]+=numerosity
                population.population[general].totalNumSumptionRemoved+=numerosity
                population.population[general].cluster.pop(d_id-count)
                population.numRules-=1
                count+=1


    ##########################################################################################################################
    ####################                          bigCirc  Error detector                                          ###########
    ####################                                     Operators                                             ###########
    ##########################################################################################################################

    #calculate the average experience
    def ER_average_experience(self,cluster):
        sum=0
        for rule in cluster.cluster:
            experience=self.Rule_Oper.Get_positive_prediction(rule)+self.Rule_Oper.Get_negative_prediction(rule)
            sum+=experience

        if len(cluster.cluster)>0:
            result=int(sum/len(cluster.cluster))
        else:
            result=0
        return result


    #Find the cluster with the largest number of rules
    def ER_max_cluster(self,population):
        result=-1
        max_value=-1
        for i in range(0,len(population.population)):
            if max_value<len(population.population[i].cluster):
                result=i
                max_value=len(population.population[i].cluster)
        return result


    #Check whether this rule is incorrect
    def ER_Is_Rule_Error(self,candidate_rule,population):
        Error_value=0
        candidate_condition=self.Rule_Oper.Get_Condition(candidate_rule)
        candidate_experience=self.Rule_Oper.Get_positive_prediction(candidate_rule)+self.Rule_Oper.Get_negative_prediction(candidate_rule)
        for cluster_id in range(len(population.population)-1,-1,-1):
            #print(cluster_id)
            for rule in population.population[cluster_id].cluster:
                condition=self.Rule_Oper.Get_Condition(rule)
                if self.Rep_Oper.Over_lapping(candidate_condition,condition):
                    
                    Error_value+=self.Rule_Oper.Get_positive_prediction(rule)+self.Rule_Oper.Get_negative_prediction(rule)
                    if Error_value>candidate_experience:
                   
                        return True
        return False


    def ER_Implement(self,target_population,compare_population):

        #max_cluster=self.ER_max_cluster(target_population)
        #threshold=self.ER_average_experience(target_population.population[max_cluster])

        
        for cluster in range(0,len(target_population.population)):

            #initial delete list
            delete_list=[]
            count=0






            for id in range(0,len(target_population.population[cluster].cluster)):
                #if cluster==max_cluster:
                #    rule=target_population.population[cluster].cluster[id]
                #    experience=self.Rule_Oper.Get_positive_prediction(rule)+self.Rule_Oper.Get_negative_prediction(rule)
                #    if experience<threshold:
                #        if self.ER_Is_Rule_Error(rule,compare_population):
               #             delete_list.append(id)

                #else:
                rule=target_population.population[cluster].cluster[id]
                if self.ER_Is_Rule_Error(rule,compare_population):
                            delete_list.append(id)


            #remove the incorrect rules
            for d_id in delete_list:
                target_population.numRules-=1
                target_population.population[cluster].cluster.pop(d_id-count)
                count+=1


    ##########################################################################################################################
    ####################                          bigCirc  CrossOver                                               ###########
    ####################                                     Population                                            ###########
    ##########################################################################################################################

    def CrossOver_Population(self, population_1, population_2, feature_size, circleId):
        for i in range(0, feature_size+1):
            if len(population_1.population[i].cluster)>0 or len(population_2.population[i].cluster)>0:
                num_add=self.CrossOver_Cluster(population_1.population[i].cluster, population_1.support_act,circleId,population_2.population[i].cluster)
                population_1.numRules+=num_add
                num_add=self.CrossOver_Cluster(population_2.population[i].cluster, population_2.support_act,circleId,population_1.population[i].cluster)
                population_2.numRules+=num_add

    #exchange rules in two clusters
    def CrossOver_Cluster(self,cluster_1,action_1,Circle_ID,cluster_2):
        appendings=[]
        for rule in cluster_2:
            encoding=self.Rule_Oper.Get_Condition(rule)
            if not self.WhetherPossessRule(cluster_1,encoding):
                appendings.append(encoding)

        #Add new rule
        for encoding in appendings:
            new_Rule=self.Rule_Oper.Create_new_Single_Rule(encoding,action_1,Circle_ID)
            cluster_1.append(new_Rule)

        # number of the added rules
        return len(appendings)

    #Judge Whether this Cluster possess this rule
    def WhetherPossessRule(self,Cluster,encoding):
        for rule_C in Cluster:
            encoding_c=self.Rule_Oper.Get_Condition(rule_C)
            if self.Rep_Oper.Is_Same_Condition(encoding, encoding_c):
                return True
        return False
