﻿import random
import math
import os



class environment:
    def __init__(self,maxipayoff):
        self.multiplexer_posbits=[1,2,3,4,5,6,7,8,9,10,11]
        self.multiplexer_length=[3,6,11,20,37,70,135,264,521,1034,2059]
        self.problems_involved=['MUX','Carry','Parity','Majority','HiddenMUX',"HiddenCarry","HiddenMaj","HierarchicallyMux"]
        self.maxPayOff=maxipayoff
        self.action=2
        self.Hidden_bits=0

     #Create a state
    def Create_Set_condition(self,length):
        state=[0]*length
        for i in range(0, length):
            random_number=random.randint(0,1)
            if(random_number==0):
                state[i]=0
            else:
                state[i]=1
        return state

    # generate multiplexer result
    def execute_Multiplexer_Action(self,state):
        actual_Action=0
        length=len(state)
        post_Bits=1
        for number in range(0,len(self.multiplexer_length)):
            if length==self.multiplexer_length[number]:
                post_Bits=self.multiplexer_posbits[number]
        place=post_Bits
        for i in range(0,post_Bits):
            if state[i]==1:
                place=place+int(math.pow(2.0,float(post_Bits-1-i)))
                #print place
        if state[place]==1:
            actual_Action=1
        return actual_Action

    # generate carry result
    def execute_Carry_Action(self,state):
        carry=0
        actual_Action=0
        half_condition=int(len(state)/2)
        for i in range(0, half_condition):
            carry=int((carry+int(state[half_condition-1-i])+int(state[half_condition-1-i+half_condition]))/2)
  
        
        if carry==1:
            actual_Action=1
        return actual_Action

    # generate even parity result
    def execute_Even_parity_Action(self,state):
        numbers=0
        actual_Action=0
        for i in range(0,len(state)):
            if state[i]==1:
                numbers=numbers+1
        if numbers%2==0:
            actual_Action=1
        return actual_Action

    # generate the majority on result
    def execute_Majority_On_Action(self,state):
        actual_Action=0
        Numbers=0
        for i in range(0,len(state)):
            if(state[i]==1):
                Numbers=Numbers+1
        if Numbers>(len(state)/2):
            actual_Action=1
        return actual_Action

    # This function is for reinforcement learning     
    def executeAction(self, exenumber,state,action):
        ret=0
        #['multiplexer','carry', 'evenParity', 'majorityOn']
        if exenumber==0:
            #result=self.execute_Multiplexer_Action(state)
            result=self.execute_Multiplexer_Action(state)
        elif exenumber==1:
            #result=self.execute_Carry_Action(state)
            result=self.execute_Carry_Action(state)
        elif exenumber==2:
            result=self.execute_Even_parity_Action(state)
        elif exenumber==3:
            #result=self.execute_Majority_On_Action(state)
            result=self.execute_Majority_On_Action(state)
        elif exenumber==4:
            result=self.execute_HiddenMultiplexer_Action(state)
        elif exenumber==5:
            result=self.execute_HiddenCarry_Action(state)
        elif exenumber==6:
            result=self.execute_HiddenMajority_On_Action(state)
        elif exenumber==7:
            result=self.execute_Hierarchically_Multiplexer_Action(state)

        if result==action:
            ret=self.maxPayOff
        return ret

    # generate a list of the attribute Id
    def Generate_attribute_List(self,length):
        result=[]
        for i in range(0,length):
            result.append(i)
        return result


    def Generate_attribute_PossibleValueLength_List_Boolean(self,length):
        result=[]
        for i in range(0,length):
            result.append(2)
        result.sort(reverse=True)
        return result


     # generate hidden multiplexer result
    def execute_HiddenMultiplexer_Action(self,state):
        actual_Action=0
        length=len(state)
        post_Bits=1
        for number in range(0,len(self.multiplexer_length)):
            if length-self.Hidden_bits==self.multiplexer_length[number]:
                post_Bits=self.multiplexer_posbits[number]
        place=post_Bits+self.Hidden_bits
        for i in range(0,post_Bits):
            if state[i]==1:
                place=place+int(math.pow(2.0,float(post_Bits-1-i)))
                #print place
        if state[place]==1:
            actual_Action=1
        return actual_Action

    #generate hidden carry result
    def execute_HiddenCarry_Action(self,state):
        carry=0
        actual_Action=0
        half_condition=int((len(state)-self.Hidden_bits)/2)
        for i in range(0, half_condition):
            carry=int((carry+int(state[half_condition-1-i])+int(state[half_condition-1-i+half_condition+self.Hidden_bits]))/2)
  
        
        if carry==1:
            actual_Action=1
        return actual_Action

    #generate hidden Majority result
    def execute_HiddenMajority_On_Action(self,state):
        actual_Action=0
        Numbers=0

        half_bit=int((len(state)-self.Hidden_bits)/2)
        for i in range(0,len(state)):
            if(state[i]==1) and (i<=half_bit or i>self.Hidden_bits+half_bit-1):
                Numbers=Numbers+1
        if Numbers>((len(state)-self.Hidden_bits)/2):
            actual_Action=1
        return actual_Action


    def execute_Hierarchically_Multiplexer_Action(self,state):
        length=18
        
        mux_state=[]

        #split into a sub problem
        for i in range(0,int(length/3)):
            #for sub problem
            new_state=state[i*3:i*3+3]
            mux_state.append(self.execute_Even_parity_Action(new_state))


        action= self.execute_Multiplexer_Action(mux_state)

        return action

    


class Prime_environment:
    def __init__(self,length,maxipayoff):
        self.IsLinux=False
        self.problems_involved=['Prime']
        self.maxPayOff=maxipayoff
        self.length=length
        self.action=2
        self.Address="PrimeNumber\\P_number.txt"
        print("begin")
        self.action_list=self.Read()

    #read information
    def Read_Information(self,address):
        read_information=open(address,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        return information

    #limitation
    def Get_MaxNumber(self):
        return 2**self.length-1

    def Read(self):
        #limitation
        Max=self.Get_MaxNumber()
        Number_List=[]
        informations=self.Read_Information(self.Address)
        for information in informations:
           numbers=information.split("\n")[0].split(' ')
           for numb in numbers:
               if int(numb)<=Max:
                   Number_List.append(int(numb))
               else:
                   #print(Number_List)
                   return Number_List
        return Number_List


    def executeAction(self, exenumber,state,action):
        ret=0
        #['Prime Number']
        if exenumber==0:
            #result=self.execute_Multiplexer_Action(state)
            result=self.execute_Prime_Action_Binary(state)
        if result==action:
            ret=self.maxPayOff
        return ret

    def execute_Prime_Action_Binary(self,state):
        count=0
        for i in range(0,self.length):
            count+=state[i]*(2**i)

        if count in self.action_list:
            return 1
        else:
            return 0


    # generate a list for action ID
    def Generate_attribute_PossibleValueLength_List_Boolean(self,length):
        result=[]
        for i in range(0,length):
            result.append(2)
        result.sort(reverse=True)
        return result

    def Generate_attribute_List(self,length):
        result=[]
        for i in range(0,length):
            result.append(i)
        return result

    
     #Create a state
    def Create_Set_condition(self,length):
        state=[0]*length
        for i in range(0, length):
            random_number=random.randint(0,1)
            if(random_number==0):
                state[i]=0
            else:
                state[i]=1
        return state



class create_global_instance:
    def __init__(self,length):
        self.inputs=[[0]*length for i in range(2**length)]
        for i in range(2**length):
            value=i
            divisor=2**length
            #fill the input bits
            for j in range(length):
                divisor/=2
                if value >=divisor:
                    self.inputs[i][j]=1
                    value -=divisor
        #print (self.inputs)

#P=Prime_environment(14,1000)

class Real_environment:
    def __init__(self,maxipayoff,exenumber):
        self.IsLinux=False
        self.problems_involved=['ZOO','Balance','Breast_Cancer']
        self.maxPayOff=maxipayoff
        self.length=None
        self.action=None
        self.state=None
        self.actions=None
        self.action_value_candidate=None
        self.current_action=None
        self.action_list=[]
        self.Initial_Real_Value(exenumber)
        self.Initial_Action_Set_candidate_Real()
        self.Initial_ActionList()
        #print(self.action_value_candidate)
        #print(self.action_list)
        print("begin")


    def Read_Information(self,path):
        read_information=open(path,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        return information 

    #For the ZOO problem
    def global_Zoo(self):
        attribute=16
        datas=[]
        actions=[]
        
        if not self.IsLinux:
            raw_information=self.Read_Information('R_env\\Zoo.txt')
        else:
            raw_information=self.Read_Information(os.getcwd()+'/Parallel_CXCS_V2/R_env/Zoo.txt')

        for raw_inf in raw_information:
            first_inf= raw_inf.split('\n')[0].split(',')
            #print first_inf
            actions.append( int(first_inf[-1])-1)
            temp=[]
            for i in range(1,len(first_inf)-1):
                temp.append(int(first_inf[i]))
            datas.append(temp)

        return actions,datas


    #Initial value
    def Initial_Action_Set_candidate_Real(self):
        value_result=[]
        for i in range(0,self.length):
            temp=[]
            value_result.append(temp)


        for j in range(0,len(self.state)):
            #print self.state
            #print len(self.state[j])
            for s_id in range(0,len(self.state[j])):
                if not self.state[j][s_id] in value_result[s_id] and self.state[j][s_id]!='?':
                    value_result[s_id].append(self.state[j][s_id])

        for temp in value_result:
            temp.sort()
        #print (value_result)

        self.action_value_candidate= value_result


    #Balance
    def global_Balance(self):
        attribute=4
        datas=[]
        actions=[]

        if self.IsLinux:
            raw_information=self.Read_Information(os.getcwd()+'/Parallel_CXCS_V2/R_env/Balance.txt')
        else:
            raw_information=self.Read_Information('R_env\\Balance.txt')


        for raw_inf in raw_information:
            first_inf= raw_inf.split('\n')[0].split(' ')
            #print len(first_inf)

            actions.append( int(first_inf[-1]))
            temp=[]
            for i in range(0,len(first_inf)-1):
                if first_inf[i] !='?':
                    temp.append(int(first_inf[i]))
                else:
                    temp.append(first_inf[i])
            datas.append(temp)

        #print actions
        #print datas
        return actions,datas



    def global_Breast_Cancer(self):
        attribute=9
        datas=[]
        actions=[]
        
       
        if self.IsLinux:
             raw_information=self.Read_Information(os.getcwd()+'/Parallel_CXCS_V2/R_env/Breast_Cancer.txt')
        else:
             raw_information=self.Read_Information('R_env\\Breast_Cancer.txt')
     
        for raw_inf in raw_information:
            first_inf= raw_inf.split('\n')[0].split(' ')
            #print len(first_inf)

            actions.append( int(first_inf[-1]))
            temp=[]
            for i in range(0,len(first_inf)-1):
                if first_inf[i] !='?':
                    temp.append(int(first_inf[i]))
                else:
                    temp.append(first_inf[i])
            datas.append(temp)

        #print actions
        #print datas
        return actions,datas


    def Initial_Real_Value(self,exenumber):
        if exenumber==0:
            self.length=16
            self.action=7
            self.actions, self.state=self.global_Zoo()
            self.Initial_Action_Set_candidate_Real()
        elif exenumber==1:
            self.length=4
            self.action=3
            self.actions, self.state=self.global_Balance()
            self.Initial_Action_Set_candidate_Real()
        elif exenumber==2:
            self.length=9
            self.action=2
            self.actions, self.state=self.global_Breast_Cancer()
            self.Initial_Action_Set_candidate_Real()


    def Create_Set_condition(self,length):
        id=random.randint(0,len(self.state)-1)
        self.current_action=self.actions[id]
        return self.state[id]

    def executeAction(self, exenumber,state,action):
        ret=0
        #['Real Value']

        result=self.current_action



        if result==action:
            ret=self.maxPayOff
        return ret

    def Initial_ActionList(self):
        for act in self.actions:
            if not act in self.action_list:
                self.action_list.append(act)
        self.action_list.sort()

    # generate a list of the attribute Id
    def Generate_attribute_List(self,length):
        result=[]
        for i in range(0,length):
            result.append(i)
        return result


    def Generate_attribute_PossibleValueLength_List_Boolean(self,length):
        result=[]
        for i in range(0,length):
            result.append(len(self.action_value_candidate[i]))
        result.sort(reverse=True)
        print(result)
        return result
#R_e=Real_environment(1000,2)
#print( R_e.Create_Set_condition(11))
#print (R_e.current_action)
#print( R_e.executeAction(0,0,0))