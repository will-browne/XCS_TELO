﻿import numpy as np
import random
from mpl_toolkits.mplot3d import axes3d
import matplotlib.pyplot as plt
import os
import matplotlib.lines as mlines
import matplotlib as mpl
import copy



class ProduceTrainingMap:

    def __init__(self, XCS, UCS, ASCS):
        self.name="T_Map"
        self.XCS_Address=XCS
        self.UCS_Address=UCS
        self.ASCS_Address=ASCS

        self.Draw_TrainingMap()
        self.Print_result()


    def GetFileList(self,path,type):
        FileList=[]
        FindPath=path
        if self.Is_File_Exist(FindPath):
            FileNames=os.listdir(FindPath)
            for i in FileNames:
                if type in i:
                    FileList.append(path+'\\'+i)
        return FileList

    def Read_Information(self,path):
        read_information=open(path,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        return information


    def Is_File_Exist(self,file_Name):
        return os.path.exists(file_Name)


    def Read_Document(self):
        XCS_Files=self.GetFileList(self.XCS_Address,".txt")

        XCS_list=[]
        for file in XCS_Files:
            information=self.Read_Information(file)
            inf_1=information[0].split("\n")[0].split(" ")

            INF_1_R=[]
            for inf in inf_1:
                if inf!="":
                    INF_1_R.append(round(float(inf)/100,2))

            inf_2=information[1].split("\n")[0].split(" ")


            INF_2_R=[]
            for inf in inf_2:
                if inf!="":
                    INF_2_R.append(int(inf))

            inf_3=information[2].split("\n")[0]
            INF_3_R=int(inf_3)
            inf_4=information[3].split("\n")[0]
            INF_4_R=int(inf_4)

            XD=XCS_Data(INF_1_R,INF_2_R,INF_3_R,INF_4_R)
            XCS_list.append(XD)
            


        UCS_Files=self.GetFileList(self.UCS_Address,".txt")
        UCS_list=[]

        for file in UCS_Files:
            information=self.Read_Information(file)
            inf_1=information[0].split("\n")[0].split(" ")

            INF_1_R=[]
            for inf in inf_1:
                if inf!="":
                    INF_1_R.append(float(inf))

            inf_2=information[1].split("\n")[0].split(" ")


            INF_2_R=[]
            for inf in inf_2:
                if inf!="":
                    INF_2_R.append(int(inf))

            inf_3=information[2].split("\n")[0]
            INF_3_R=int(inf_3)
            inf_4=information[3].split("\n")[0]
            INF_4_R=int(inf_4)

            UD=UCS_Data(INF_1_R,INF_2_R,INF_3_R,INF_4_R)
            UCS_list.append(UD)



        ASCS_Files=self.GetFileList(self.ASCS_Address,".txt")
        ASCS_list=[]
        for file in ASCS_Files:
            information=self.Read_Information(file)
            inf_1=information[0].split("::")[1].split("\n")[0].split(" ")
            INF_1_R=[]
            for inf in inf_1:
                if inf!="":
                    INF_1_R.append(float(inf))


            inf_1_A=information[1].split("::")[1].split("\n")[0].split(" ")
            INF_1_R_A=[]
            for inf in inf_1_A:
                if inf!="":
                    INF_1_R_A.append(float(inf))


            inf_2=information[2].split("::")[1].split("\n")[0].split(" ")
            INF_2_R=[]
            for inf in inf_2:
                if inf!="":
                    INF_2_R.append(int(inf))


            inf_2_A=information[3].split("::")[1].split("\n")[0].split(" ")
            INF_2_R_A=[]
            for inf in inf_2_A:
                if inf!="":
                    INF_2_R_A.append(int(inf))



            inf_3=information[5].split("::")[1].split("\n")[0]
            INF_3_R=int(inf_3)
            inf_4=information[6].split("::")[1].split("\n")[0]
            INF_4_R=int(inf_4)
            ASD=ASCS_Data(INF_1_R,INF_1_R_A,INF_2_R,INF_2_R_A,INF_3_R,INF_4_R)
            ASCS_list.append(ASD)
            #print (ASD.First_Time)
        return XCS_list, UCS_list, ASCS_list


    def Average_Result(self):
        XCS_list, UCS_list, ASCS_list=self.Read_Document()

        XCS_Avg= copy.deepcopy(XCS_list[0])

        #initial value
        for i in range(0,len(XCS_Avg.Training_Accuracy)):
            XCS_Avg.Training_Accuracy[i]=0
            for j in range(0,len(XCS_list)):
                XCS_Avg.Training_Accuracy[i]+=XCS_list[j].Training_Accuracy[i]
            XCS_Avg.Training_Accuracy[i]=round((XCS_Avg.Training_Accuracy[i]/len(XCS_list)),2)

        
        for i in range(0,len(XCS_Avg.Rule_Num)):
            XCS_Avg.Rule_Num[i]=0
            for j in range(0,len(XCS_list)):
                XCS_Avg.Rule_Num[i]+=XCS_list[j].Rule_Num[i]
            XCS_Avg.Rule_Num[i]=int(XCS_Avg.Rule_Num[i]/len(XCS_list))

        XCS_Avg.Complete_Time=0
        #XCS_Avg.Rule_Num[0]=0


        for j in range(0,len(XCS_list)):
            XCS_Avg.Complete_Time+=XCS_list[j].Complete_Time
        XCS_Avg.Complete_Time=int(XCS_Avg.Complete_Time/len(XCS_list))


        XCS_Avg.First_Time=0
        for j in range(0,len(XCS_list)):
            XCS_Avg.First_Time+=XCS_list[j].First_Time
        XCS_Avg.First_Time=int(XCS_Avg.First_Time/len(XCS_list))
       

        UCS_Avg=copy.deepcopy(UCS_list[0])

        for i in range(0,len(UCS_Avg.Training_Accuracy)):
            UCS_Avg.Training_Accuracy[i]=0
            for j in range(0,len(UCS_list)):
                UCS_Avg.Training_Accuracy[i]+=UCS_list[j].Training_Accuracy[i]
            UCS_Avg.Training_Accuracy[i]=round((UCS_Avg.Training_Accuracy[i]/len(UCS_list)),2)


        for i in range(0,len(UCS_Avg.Rule_Num)):
            UCS_Avg.Rule_Num[i]=0
            for j in range(0,len(UCS_list)):
                UCS_Avg.Rule_Num[i]+=UCS_list[j].Rule_Num[i]
            UCS_Avg.Rule_Num[i]=int(UCS_Avg.Rule_Num[i]/len(UCS_list))
        UCS_Avg.Complete_Time=0
        for j in range(0,len(UCS_list)):
            UCS_Avg.Complete_Time+=UCS_list[j].Complete_Time
        UCS_Avg.Complete_Time=int(UCS_Avg.Complete_Time/len(UCS_list))

        #UCS_Avg.Rule_Num[0]=0
        UCS_Avg.First_Time=0
        for j in range(0,len(UCS_list)):
            UCS_Avg.First_Time+=UCS_list[j].First_Time
        UCS_Avg.First_Time=int(UCS_Avg.First_Time/len(UCS_list))


        ASCS_Avg=copy.deepcopy(ASCS_list[0])
        
        for i in range(0,len(ASCS_Avg.Training_Accuracy_Before)):
            ASCS_Avg.Training_Accuracy_Before[i]=0
            for j in range(0,len(ASCS_list)):
                ASCS_Avg.Training_Accuracy_Before[i]+=ASCS_list[j].Training_Accuracy_Before[i]
            ASCS_Avg.Training_Accuracy_Before[i]=round((ASCS_Avg.Training_Accuracy_Before[i]/len(ASCS_list)),2)

        for i in range(0,len(ASCS_Avg.Training_Accuracy_After)):
            ASCS_Avg.Training_Accuracy_After[i]=0
            for j in range(0,len(ASCS_list)):
                ASCS_Avg.Training_Accuracy_After[i]+=ASCS_list[j].Training_Accuracy_After[i]
            ASCS_Avg.Training_Accuracy_After[i]=round((ASCS_Avg.Training_Accuracy_After[i]/len(ASCS_list)),2)


        for i in range(0,len(ASCS_Avg.Rule_Num_Before)):
            ASCS_Avg.Rule_Num_Before[i]=0
            for j in range(0,len(ASCS_list)):
                ASCS_Avg.Rule_Num_Before[i]+=ASCS_list[j].Rule_Num_Before[i]
            ASCS_Avg.Rule_Num_Before[i]=int(ASCS_Avg.Rule_Num_Before[i]/len(ASCS_list))


        for i in range(0,len(ASCS_Avg.Rule_Num_After)):
            ASCS_Avg.Rule_Num_After[i]=0
            for j in range(0,len(ASCS_list)):
                ASCS_Avg.Rule_Num_After[i]+=ASCS_list[j].Rule_Num_After[i]
            ASCS_Avg.Rule_Num_After[i]=int(ASCS_Avg.Rule_Num_After[i]/len(ASCS_list))

        #ASCS_Avg.Rule_Num_After.insert(0,0)
        #ASCS_Avg.Rule_Num_Before.insert(0,0)
        ASCS_Avg.Complete_Time=0
        for j in range(0,len(ASCS_list)):
            ASCS_Avg.Complete_Time+=ASCS_list[j].Complete_Time
        ASCS_Avg.Complete_Time=int(ASCS_Avg.Complete_Time/len(ASCS_list))


        ASCS_Avg.First_Time=0
        for j in range(0,len(ASCS_list)):
            ASCS_Avg.First_Time+=ASCS_list[j].First_Time
        ASCS_Avg.First_Time=int(ASCS_Avg.First_Time/len(ASCS_list))

        #print(ASCS_Avg.Complete_Time)
        return XCS_Avg, UCS_Avg, ASCS_Avg


    def Print_Result(self,XCS_Avg, UCS_Avg, ASCS_Avg):
        print("Time",XCS_Avg.First_Time, UCS_Avg.First_Time, ASCS_Avg.First_Time )
        print("Rules", XCS_Avg.Rule_Num[-1], UCS_Avg.Rule_Num[-1],ASCS_Avg.Rule_Num_Before[-1],ASCS_Avg.Rule_Num_After[-1] )
        print("Accuracy",XCS_Avg.Training_Accuracy[-1], UCS_Avg.Training_Accuracy[-1], ASCS_Avg.Training_Accuracy_Before[-1],ASCS_Avg.Training_Accuracy_After[-1])


    def Draw_TrainingMap(self):
        XCS_Avg, UCS_Avg, ASCS_Avg=self.Average_Result()

        self.Print_Result(XCS_Avg, UCS_Avg, ASCS_Avg)
        
        XCS_MAX=False
        UCS_MAX=False
        ASCS_MAX_AFTER=False
        ASCS_MAX_BEFORE=False


        step_length=5000
        #length=len(ASCS_Avg.Rule_Num_Before)
        #length=40
        length=40
        step=[]
        for i in range(1,length+1):
            step.append(i*step_length)
        #20-BITS Multiplexer
        #print GP_avg
        XCS_PLOT=XCS_Avg.Rule_Num[1:41]
        UCS_PLOT=UCS_Avg.Rule_Num[1:41]
        ASCS_BEFORE_PLOT=ASCS_Avg.Rule_Num_Before
        ASCS_AFTER_PLOT=ASCS_Avg.Rule_Num_After


        #10 car
        #XCS_PLOT=XCS_Avg.Rule_Num[1:41]
        #UCS_PLOT=UCS_Avg.Rule_Num[1:41]
        #ASCS_BEFORE_PLOT=ASCS_Avg.Rule_Num_Before[0:40]
        #ASCS_AFTER_PLOT=ASCS_Avg.Rule_Num_After[0:40]


        #8 MajorityOn
        #XCS_PLOT=XCS_Avg.Rule_Num[1:81]
        #UCS_PLOT=UCS_Avg.Rule_Num[1:81]
        #ASCS_BEFORE_PLOT=ASCS_Avg.Rule_Num_Before[0:80]
        #ASCS_AFTER_PLOT=ASCS_Avg.Rule_Num_After[0:80]
        #print X
        font={'family':'serif','color':'red','weight':'normal','size':16,}
        #plt.ylim(0,101)
        """
        blue_patch = mlines.Line2D([], [], color='b', marker='^',
                          markersize=8, label='Standard XCS Training Accuracy')
        green_patch = mlines.Line2D([], [], color='g', marker='*',
                          markersize=8, label='Standard XCS Converge Accuracy')
        red_patch = mlines.Line2D([], [], color='r' , marker='d',
                          markersize=8, label='absumption XCS Training Accuracy')
        cyan_patch = mlines.Line2D([], [], color='c' , marker='+',
                          markersize=8, label='absumption XCS Converge Accuracy')



        plt.legend(handles=[blue_patch,green_patch,red_patch,cyan_patch])
        """
        plt.ylabel('number of rules',fontdict=font)
        plt.xlabel('number of instances',fontdict=font)
        #plt.title('8-bits Majority-On',fontdict=font)
        #plt.title('10-bits Carry',fontdict=font)
        plt.title('20-bits Multiplexer',fontdict=font)


        plt.plot(step,XCS_PLOT,'^',color='b')
        plt.plot(step,XCS_PLOT,'--',color='b')
        """
        for i in range(0,len(GP_avg)):
            temp_X=[]
            temp_X.append(X[i])
            temp_X.append(X[i])
            temp_Y=[]
            temp_Y.append(LCS_max[i])
            temp_Y.append(LCS_min[i])
            #print temp_X
            #print temp_Y
            plt.plot(temp_X,temp_Y,'--',color='b')
        """
        plt.plot(step,UCS_PLOT,'*',color='g')
        plt.plot(step,UCS_PLOT,'--',color='g')

        plt.plot(step,ASCS_AFTER_PLOT,'d',color='r')
        plt.plot(step,ASCS_AFTER_PLOT,'--',color='r')

        plt.plot(step,ASCS_BEFORE_PLOT,'+',color='black')
        plt.plot(step,ASCS_BEFORE_PLOT,'--',color='black')
        print(UCS_Avg.Training_Accuracy)

        #drew when reach max accuracy
        for i in range(1,len(ASCS_Avg.Rule_Num_Before)+1):
            
            if UCS_Avg.Training_Accuracy[i-1]==1.0 and UCS_MAX==False:
                UCS_MAX=True
                X=step_length*(i+1)
                Y1= int(UCS_Avg.Rule_Num[i]*1.1)
                #print(UCS_Avg.Rule_Num[i]*1.1)
                #Y2= int(UCS_Avg.Rule_Num[i]*0.9)
                #print(UCS_Avg.Rule_Num[i]*0.9)
                X_L=[X,X]
                Y_L=[0,Y1]
                #print([X,Y1],[X,Y2])
                plt.plot(X_L,Y_L,'--',color='g')
                plt.text(X,UCS_Avg.Rule_Num[i]*0.76,'('+str(X)+')',color='g')

            if XCS_Avg.Training_Accuracy[i-1]==1.0 and XCS_MAX==False:
                XCS_MAX=True
                X=step_length*(i+1)
                Y1= int(XCS_Avg.Rule_Num[i]*1.1)
                #print(UCS_Avg.Rule_Num[i]*1.1)
                #Y2= int(UCS_Avg.Rule_Num[i]*0.9)
                #print(UCS_Avg.Rule_Num[i]*0.9)
                X_L=[X,X]
                Y_L=[0,Y1]
                #print([X,Y1],[X,Y2])
                plt.plot(X_L,Y_L,'--',color='b')
                plt.text(X,XCS_Avg.Rule_Num[i]*1.03,'('+str(X)+')',color='b')

        for i in range(0,len(ASCS_Avg.Rule_Num_Before)):

            if ASCS_Avg.Training_Accuracy_Before[i]==1.0 and ASCS_MAX_BEFORE==False:
                ASCS_MAX_BEFORE=True
                X=step_length*(i+1)
                Y1= int(ASCS_Avg.Rule_Num_Before[i]*1.2)
                #print(UCS_Avg.Rule_Num[i]*1.1)
                #Y2= int(UCS_Avg.Rule_Num[i]*0.9)
                #print(UCS_Avg.Rule_Num[i]*0.9)
                X_L=[X,X]
                Y_L=[0,Y1]
                #print([X,Y1],[X,Y2])
                plt.plot(X_L,Y_L,':',color='black')
                plt.text(X+2000,ASCS_Avg.Rule_Num_Before[i]*1.2,'('+str(X)+')',color='black')

            if ASCS_Avg.Training_Accuracy_After[i]==1.0 and ASCS_MAX_AFTER==False:
                ASCS_MAX_AFTER=True
                X=step_length*(i+1)
                Y1= int(ASCS_Avg.Rule_Num_After[i]*3.5)
                #print(UCS_Avg.Rule_Num[i]*1.1)
                #Y2= int(UCS_Avg.Rule_Num[i]*0.9)
                #print(UCS_Avg.Rule_Num[i]*0.9)
                X_L=[X,X]
                Y_L=[0,Y1]
                #print([X,Y1],[X,Y2])
                plt.plot(X_L,Y_L,'--',color='r')
                plt.text(X,ASCS_Avg.Rule_Num_After[i]*-0.5,'('+str(X)+')',color='r')


            




        plt.show()

    def Print_result(self):
        XCS_Avg, UCS_Avg, ASCS_Avg=self.Average_Result()

        self.Print_Result(XCS_Avg, UCS_Avg, ASCS_Avg)


class XCS_Data:
    def __init__(self,T,R,C,F):
        self.Training_Accuracy=T

        self.Rule_Num=R

        self.Complete_Time=C

        self.First_Time=F


class UCS_Data:
    def __init__(self,T,R,C,F):
        self.Training_Accuracy=T

        self.Rule_Num=R

        self.Complete_Time=C

        self.First_Time=F

class ASCS_Data:
    def __init__(self,TB,TA,RB,RA,C,F):
        self.Training_Accuracy_Before=TB

        self.Training_Accuracy_After=TA

        self.Rule_Num_Before=RB

        self.Rule_Num_After=RA

        self.Complete_Time=C

        self.First_Time=F

XCS_Add="TMap\\XCS\\mux20"


UCS_Add="TMap\\UCS\\mux20"

ASCS_Add="TMap\\ASCS\\mux20"



#XCS_Add="TMap\\XCS\\CAR10"

#UCS_Add="TMap\\UCS\\CAR10"

#ASCS_Add="TMap\\ASCS\\CAR10"



#XCS_Add="TMap\\XCS\\MAJ8"

#UCS_Add="TMap\\UCS\\MAJ8"

#ASCS_Add="TMap\\ASCS\\MAJ8"



#XCS_Add="TMap\\XCS\\CAR14"

#UCS_Add="TMap\\UCS\\CAR14"

#ASCS_Add="TMap\\ASCS\\CAR14"


PTM=ProduceTrainingMap(XCS_Add,UCS_Add,ASCS_Add)