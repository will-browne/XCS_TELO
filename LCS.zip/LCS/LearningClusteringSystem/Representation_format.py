﻿import copy
import random

class Ternary_Alphabet:
    def __init__(self):
        self.type='Ternary Alphabet'


    ### Whether a condition match a state ###########
    def isConditionMatched(self,state,condition):
        for i in range(0,len(state)):
        #self.config.dontcare
            if condition[i]!='#' and condition[i] != state[i]:
                return False
        return True


    #Create a condition, which match the input state
    def createCondition_GeneralLevel(self,state,general_level,attribute_list):
        condition=copy.deepcopy(state)
        #print(attribute_list)
        #print(general_level)
        candidates=random.sample(attribute_list,general_level)
        for can in candidates:
            condition[can]='#'
        return condition


    #Absumption operator of condition
    def Absumption_Condition(self,state,condition,search_gener):
        result=copy.deepcopy(condition)
        candidates=[]
        specialized=[]


        for i in range(0,len(condition)):
                if condition[i] == '#':
                    candidates.append(i)
                else:
                    specialized.append(i)

        reduced_gener= len(candidates)-search_gener


        
        #specific operator
        if reduced_gener<=len(candidates) and reduced_gener!=0:
            candidate=random.sample(candidates,reduced_gener)

        else:
            if reduced_gener!=0:
                #candidate=candidates
                return None
            else:
                candidate=random.sample(candidates,1)

        #do the absumption
        for candi in candidate:
            if state[candi]==1:
                result[candi]=0
            else:
                result[candi]=1

        if reduced_gener==0:
            spe_candidate=random.sample(specialized,1)[0]
            result[spe_candidate]='#'
        
        return result


    #compare two condition
    def Is_Same_Condition(self,condition_1,condition_2):
        for i in range(0,len(condition_1)):
            if condition_1[i] != condition_2[i]:
                return False
        return True


    #Gener search operator of condition             
    def Gener_Condition(self,condition,search_gener,state):
        result=copy.deepcopy(condition)
        candidates=[]
        specialized=[]


        for i in range(0,len(condition)):
                if condition[i] == '#':
                    candidates.append(i)
                else:
                    specialized.append(i)

        increase_gener=search_gener-len(candidates)


        #gener operator if equal change an general attribute else gener gener size attributes
        if increase_gener==0:
            if search_gener<len(condition) and search_gener>0:
                sp_id=random.sample(candidates,1)[0]
                gen_id=random.sample(specialized,1)[0]
                result[sp_id]=state[sp_id]
                result[gen_id]='#'             
        else:
            gen_ids=random.sample(specialized,increase_gener)
            for gen_id in gen_ids:
                result[gen_id]='#'
        
        return result


    #check whether two rules conflit
    def Over_lapping(self,condition_1, condition_2):
        for i in range(0,len(condition_1)):
            if condition_1[i] !='#' and condition_2[i]!='#' and condition_1[i]!=condition_2[i]:
                return False
        return True


    #check condition is subsumable
    def Is_Condition_Subsumeable(self,condition_subsumable,condition_candidate):
        for i in range(0,len(condition_subsumable)):
            if condition_subsumable[i]!='#' and condition_subsumable[i] != condition_candidate[i]:
                return False
        return True



class Interger_Alphabet:
    def __init__(self,attribute_value_list):
        self.type='Interger Alphabet'
        self.attribute_value_list=attribute_value_list


    ### Whether a condition match a state ###########
    def isConditionMatched(self,state,condition):
        for i in range(0,len(state)):
        #self.config.dontcare
            if condition[i]!='#' and condition[i] != state[i] and state[i]!='?':
                return False
        return True


    #Create a condition, which match the input state
    def createCondition_GeneralLevel(self,state,general_level,attribute_list):
        condition=copy.deepcopy(state)
        #print(attribute_list)
        #print(general_level)
        candidates=random.sample(attribute_list,general_level)
        for id in range(0,len(state)):
            if state[id]=='?':
                plausible_value=copy.deepcopy(self.attribute_value_list[id])
                condition[id]=random.sample(plausible_value,1)[0]
            if id in candidates:
                condition[id]='#'

        return condition


    #Absumption operator of condition
    def Absumption_Condition(self,state,condition,search_gener):
        result=copy.deepcopy(condition)
        candidates=[]
        specialized=[]
        current_gener=0


        for i in range(0,len(condition)):
                if condition[i] == '#' and state[i]!='?':
                    candidates.append(i)

                if condition[i] != '#':
                    specialized.append(i)

                if condition[i] == '#':
                    current_gener+=1

        reduced_gener= current_gener-search_gener



        
        #specific operator
        if reduced_gener<=len(candidates) and reduced_gener!=0 :
            candidate=random.sample(candidates,reduced_gener)

        else:
            if reduced_gener!=0 :
                #candidate=candidates
                return None
            else:
                candidate=random.sample(candidates,1)

        #do the absumption
        for candi in candidate:
            plausible_value=copy.deepcopy(self.attribute_value_list[candi])
            plausible_value.remove(state[candi])
            result[candi]=random.sample(plausible_value,1)[0]




        if reduced_gener==0:
            if len(specialized)>0:
                spe_candidate=random.sample(specialized,1)[0]
                result[spe_candidate]='#'
            else:
                return None
        
        return result


    #compare two condition
    def Is_Same_Condition(self,condition_1,condition_2):
        for i in range(0,len(condition_1)):
            if condition_1[i] != condition_2[i]:
                return False
        return True


    #Gener search operator of condition             
    def Gener_Condition(self,condition,search_gener,state):
        result=copy.deepcopy(condition)
        candidates=[]
        specialized=[]


        for i in range(0,len(condition)):
                if condition[i] == '#':
                    candidates.append(i)
                else:
                    specialized.append(i)

        increase_gener=search_gener-len(candidates)


        #gener operator if equal change an general attribute else gener gener size attributes
        if increase_gener==0:
            if search_gener<len(condition) and search_gener>0:
                sp_id=random.sample(candidates,1)[0]
                gen_id=random.sample(specialized,1)[0]
                if state[sp_id]!='?':
                    result[sp_id]=state[sp_id]
                else:
                    plausible_value=copy.deepcopy(self.attribute_value_list[sp_id])
                    result[sp_id]=random.sample(plausible_value,1)[0]
                result[gen_id]='#'             
        else:
            #print(specialized,increase_gener)
            gen_ids=random.sample(specialized,increase_gener)
            for gen_id in gen_ids:
                result[gen_id]='#'
        
        return result


    #check condition is subsumable
    def Is_Condition_Subsumeable(self,condition_subsumable,condition_candidate):
        for i in range(0,len(condition_subsumable)):
            if condition_subsumable[i]!='#' and condition_subsumable[i] != condition_candidate[i]:
                return False
        return True


    #check whether two rules conflit
    def Over_lapping(self,condition_1, condition_2):
        for i in range(0,len(condition_1)):
            if condition_1[i] !='#' and condition_2[i]!='#' and condition_1[i]!=condition_2[i]:
                return False
        return True